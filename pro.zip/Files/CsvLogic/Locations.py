from Files.CsvReader import CsvReader
import csv

class Locations:
    def GetGameModeString(self, GameModeID):
        reader = CsvReader()
        RowData = reader.readCsv('GameAssets/csv_logic/locations.csv')
        for row in RowData:
            if RowData.index(row) == GameModeID:
                return row[14]
            
    def getAllLocations():

        BrawlersID = []

        with open('GameAssets/csv_logic/locations.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[1].lower() != 'true':
                        BrawlersID.append(line_count - 2)
                    line_count += 1


            return BrawlersID
        
    def getAllLocationsWithGamemode(gamemode):

        BrawlersID = []

        with open('GameAssets/csv_logic/locations.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[1].lower() != 'true' and row[14] == gamemode:
                        BrawlersID.append(line_count - 2)
                    line_count += 1


            return BrawlersID
        
    def getAllLocationsWithException(gamemode):

        BrawlersID = []

        with open('GameAssets/csv_logic/locations.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[1].lower() != 'true' and row[14] not in gamemode:
                        BrawlersID.append(line_count - 2)
                    line_count += 1


            return BrawlersID