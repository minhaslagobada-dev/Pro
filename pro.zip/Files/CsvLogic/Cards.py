import csv

class Cards:

    def get_spg_id():

        CardSkillsID = []

        with open('GameAssets/csv_logic/cards.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[5].lower() == '4' or row[5].lower() == '5':
                        CardSkillsID.append(line_count - 2)
                    line_count += 1


            return CardSkillsID


    def get_spg_by_brawler_id(self, brawler_id, type):
        char_file =  open('GameAssets/csv_logic/characters.csv')
        csv_reader = csv.reader(char_file, delimiter=',')
        line_count = 0

        for row in csv_reader:
            if line_count == 0 or line_count == 1:
                line_count += 1
            else:
                line_count += 1
                if line_count == brawler_id + 3:
                    name = row[0]
                    line_count += 1

                    cards_file = open('GameAssets/csv_logic/cards.csv')
                    csv_reader = csv.reader(cards_file, delimiter=',')
                    line_count = 0

                    for row in csv_reader:
                        if line_count == 0 or line_count == 1:
                            line_count += 1
                        else:
                            line_count += 1
                            if type == 4:
                                if row[5].lower() == '4' and row[3] == name:
                                    id = line_count - 3
                                    char_file.close()
                                    cards_file.close()
                                    return id


    def get_unlocked_spg(self, brawler_id):
        char_file =  open('GameAssets/csv_logic/characters.csv')
        csv_reader = csv.reader(char_file, delimiter=',')
        line_count = 0
        id = []

        for row in csv_reader:
            if line_count == 0 or line_count == 1:
                line_count += 1
            else:
                line_count += 1
                if line_count == brawler_id + 3:
                    name = row[0]
                    line_count += 1

                    cards_file = open('GameAssets/csv_logic/cards.csv')
                    csv_reader = csv.reader(cards_file, delimiter=',')
                    line_count = 0

                    for row in csv_reader:
                        if line_count == 0 or line_count == 1:
                            line_count += 1
                        else:
                            line_count += 1
                            if row[5].lower() == '4' and row[3] == name and row[4] != "true" or row[3] == name and row[5].lower() == '5' and row[4] != "true":
                                id.append(line_count - 3)

                    return id
                    char_file.close()
                    cards_file.close()


    def get_brawler_unlock():

        CardUnlockID = []

        with open('GameAssets/csv_logic/cards.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[4].lower() == '0':
                        CardUnlockID.append(line_count - 2)
                    line_count += 1


            return CardUnlockID
        
    def get_brawler_star_power(char):
        with open('GameAssets/csv_logic/characters.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            characters = list(csv_reader)

        characters = characters[2:] 

        if char >= len(characters):
            return 0

        name = characters[char][0]

        with open('GameAssets/csv_logic/cards.csv') as card_file:
            csv_reader = csv.reader(card_file, delimiter=',')
            cards = list(csv_reader)
        cards = cards[2:]
        for index, row in enumerate(cards):
            if row[3] == name and row[4].strip() == '4':
                return index
        return 0
        
    def get_brawler_rarity(cardID):
        brawler_rarity = None
        with open('GameAssets/csv_logic/cards.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            next(csv_reader) 
            next(csv_reader) 
            for count, row in enumerate(csv_reader, start=1):
                if count == cardID - 1:
                    brawler_rarity = row[10]
                    break
        return brawler_rarity



    def get_brawler_unlock_by_character(char):
    
        with open('GameAssets/csv_logic/characters.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            characters = list(csv_reader)

        characters = characters[2:] 

        if char >= len(characters):
            return 0

        name = characters[char][0]

        with open('GameAssets/csv_logic/cards.csv') as card_file:
            csv_reader = csv.reader(card_file, delimiter=',')
            cards = list(csv_reader)
        cards = cards[2:]
        for index, row in enumerate(cards):
            if row[3] == name and row[4].strip() == '0':
                return index
        return 0
