import csv

class Characters:

    def get_brawlers_id():

        BrawlersID = []

        with open('GameAssets/csv_logic/characters.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[20] == 'Hero' and row[2].lower() != 'true' and row[1].lower() != 'true':
                        BrawlersID.append(line_count - 2)
                    line_count += 1


            return BrawlersID
        
    def getBrawlerName(brawlerID):
        brawler_name = None
        with open('GameAssets/csv_logic/cards.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            next(csv_reader) 
            next(csv_reader) 
            for count, row in enumerate(csv_reader, start=1):
                if count == brawlerID:
                    brawler_name = row[0]
                    break
        return brawler_name
    
    def getBrawlerByName(name):

        BrawlersID = None

        with open('GameAssets/csv_logic/characters.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:

                if line_count == 0 or line_count == 1:
                    line_count += 1
                else:
                    if row[0] == name:
                        BrawlersID = line_count - 2
                    line_count += 1
            if BrawlersID == None:
                BrawlersID = 0
            return BrawlersID


    
    def get_brawler_by_skin_id(self, skin_id):
        sconf_file = open('GameAssets/csv_logic/skins.csv')
        csv_reader = csv.reader(sconf_file, delimiter=',')
        line_count = 0
        conf = []
        for row in csv_reader:
            if row[0] == conf:
                brawler = row[1]

                char_file = open('GameAssets/csv_logic/characters.csv')
                csv_reader = csv.reader(char_file, delimiter=',')
                line_count = 0

                for row in csv_reader:
                    if line_count == 0 or line_count == 1:
                        line_count += 1
                    else:
                        line_count += 1
                        if row[0] == brawler:
                            id = line_count - 3

                            sconf_file.close()
                            char_file.close()

                            return id


