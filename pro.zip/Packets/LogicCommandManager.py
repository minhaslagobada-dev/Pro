from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.Client.LogicUpgradeBrawler import Upgrade_Brawler
from Packets.Commands.Client.LogicSetPlayerThumbnailCommand import LogicSetPlayerThumbnailCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.Commands.Client.LogicPurchaseHeroLvlUpMaterialCommand import LogicPurchaseHeroLvlUpMaterialCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Database.DatabaseManager import DataBase
from Packets.Commands.Client.LogicUnlockSkinCommand import LogicUnlockSkinCommand
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicClearShopTickersCommand import LogicClearShopTickersCommand
from random import choice
from string import ascii_uppercase
import json
class EndClientTurn(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.readBoolean()
        self.readVInt()
        self.readVInt()
        self.count = self.readVInt()
        self.commandID = []
        for x in range(self.count):
            self.commandID.append(self.readVInt())


    def process(self, crypter):
      db = DataBase(self.player)
      for x in range(self.count):
        if self.commandID[x] == 500 or self.commandID[x] == 535:
            LogicPurchaseBoxCommand.decode(self)
            LogicPurchaseBoxCommand.process(self, crypter)
            
        elif self.commandID[x] == 517:
            LogicClaimRankUpRewardCommand.decode(self)
            LogicClaimRankUpRewardCommand.process(self, crypter)
            
        elif self.commandID[x] == 515:
            LogicClearShopTickersCommand.decode(self)
            LogicClearShopTickersCommand.process(self, crypter)

        elif self.commandID[x] == 519:
            LogicPurchaseOfferCommand.decode(self)
            LogicPurchaseOfferCommand.process(self, crypter)

        elif self.commandID[x] == 505:
            LogicSetPlayerThumbnailCommand.decode(self)
            LogicSetPlayerThumbnailCommand.process(self, crypter)

        elif self.commandID[x] == 506:
            LogicSelectSkinCommand.decode(self)
            LogicSelectSkinCommand.process(self, crypter)
        
        elif self.commandID[x] == 507:
            LogicUnlockSkinCommand.decode(self)
            LogicUnlockSkinCommand.process(self, crypter)

        elif self.commandID[x] == 520:
            Upgrade_Brawler.decode(self)
            Upgrade_Brawler.process(self, crypter)

        elif self.commandID[x] == 521:
            LogicPurchaseHeroLvlUpMaterialCommand.decode(self)
            LogicPurchaseHeroLvlUpMaterialCommand.process(self, crypter)
            
        elif self.commandID[x] == 522:
            pass # i dont need brawler seen stuf rn

        elif self.commandID[x] == 509:
            LogicPurchaseDoubleCoinsCommand.decode(self)
            LogicPurchaseDoubleCoinsCommand.process(self, crypter)
            
        elif self.commandID[x] < 500 or self.commandID[x] > 570:
            pass #i dont need to handle packets command or bugged shits

        else:
            print("CommandID:", self.commandID[x], "not handled!")