import random
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Logic.Boxes import Boxes
from Utils.Writer import Writer
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Entries.LogicServerCommand import LogicServerCommand

class LogicBoxDataCommand(Writer):

    def __init__(self, client, player, boxID, rewards = None, rewardNames = None, rewardsTargetBrawler = None):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.boxID = boxID
        if rewards != None:
            self.rewards = rewards
            self.rewardNames = rewardNames
            self.rewardsTargetBrawler = rewardsTargetBrawler

    def getRewards(self):
        db = DataBase(self.player)
        self.isTrophyRoad = False
        self.hasStarPower = False
        self.hasBrawler = (random.randint(0, 5) == 2)
        self.hasBonus = (random.randint(0, 5) == 2)
        starPowerableBrawlers = []
        for key, brawler_id in self.player.unlocked_brawlers.items():
            brawlerLevel = brawler_id["PowerLevel"]
            starPower = brawler_id["StarPower"]
            if brawlerLevel >= 8 and brawler_id["StarPower"] == 0:
                starPowerableBrawlers.append(int(key))
                
        #print(starPowerableBrawlers)
        if len(starPowerableBrawlers) != 0:
            self.hasStarPower = (random.randint(0, 1) == 1)
            self.hasBrawler = not self.hasStarPower
        boxType = self.getBoxType(self.boxID)
        if boxType == 10:
            self.hasBonus = False
        coinsRange = [13, 70] if boxType == 10 else [25, 105] if boxType == 12 else [100, 250]
        tokenDoublersRange = [200] if boxType == 10 else [200, 400] if boxType == 12 else [200, 400, 600]
        powerPointsRandomRange = [4, 25] if boxType == 10 else [5, 30] if boxType == 12 else [5, 50]
        if (self.hasBrawler or self.hasStarPower) and boxType != 10:
            powerPointsRange = 1 if boxType == 10 else 2 if boxType == 12 else 4
        elif not (self.hasBrawler or self.hasStarPower):
            powerPointsRange = 2 if boxType == 10 else 3 if boxType == 12 else 5
        elif (self.hasBrawler or self.hasStarPower) and boxType == 10:
            powerPointsRange = 0
        if boxType == 11 and (self.hasBrawler or self.hasStarPower):
            powerPointsRange += 1
        unlockedBrawlers = []
        unlockableBrawlers = Characters.get_brawlers_id()
        

        for key, brawlerID in self.player.unlocked_brawlers.items():
            unlockedBrawlers.append(int(key))
            unlockableBrawlers.remove(int(key))
        unlockedBrawlersNotMaxed = []
        for brawler in unlockedBrawlers:
            if self.player.unlocked_brawlers[str(brawler)]["PowerPoints"] < 1410:
                unlockedBrawlersNotMaxed.append(brawler)
        unlockableBrawlersRare = []
        unlockableBrawlersSuperRare = []
        unlockableBrawlersEpic = []
        unlockableBrawlersMegaEpic = []
        unlockableBrawlersLegendary = []
        for brawler in unlockableBrawlers:
            cardID = Cards.get_brawler_unlock_by_character(brawler) + 2
            rarity = Cards.get_brawler_rarity(cardID)
            if rarity == "rare":
                unlockableBrawlersRare.append(brawler)
            elif rarity == "super_rare":
                unlockableBrawlersSuperRare.append(brawler)
            elif rarity == "epic":
                unlockableBrawlersEpic.append(brawler)
            elif rarity == "mega_epic":
                unlockableBrawlersMegaEpic.append(brawler)
            elif rarity == "legendary":
                unlockableBrawlersLegendary.append(brawler)
            elif rarity == "common":
                pass
            else:
                print(f"[ERROR] Unknown rarity {rarity}!")
        self.rewardNames = []
        self.rewards = []
        self.rewardsTargetBrawler = []
        if (not (self.hasBrawler or self.hasStarPower) and boxType == 10) or boxType != 10:
         self.rewards.append(random.randint(coinsRange[0], coinsRange[1]))
         self.rewardNames.append("Coins")
         self.rewardsTargetBrawler.append(0)
         self.player.gold += self.rewards[0]
         db.replaceValue("gold", self.player.gold)
         if len(self.player.unlocked_brawlers) < powerPointsRange:
             powerPointsRange = len(self.player.unlocked_brawlers)
         targetBrawlers = random.sample(unlockedBrawlersNotMaxed, powerPointsRange)
         for targetBrawler in targetBrawlers:
            reward = random.randint(powerPointsRandomRange[0], powerPointsRandomRange[1])
            if self.player.unlocked_brawlers[str(targetBrawler)]["PowerPoints"]  + reward > 1410:
                reward = 1410 - self.player.unlocked_brawlers[str(targetBrawler)]["PowerPoints"]
            self.rewards.append(reward)
            self.rewardNames.append("UpgradePoints")
            self.rewardsTargetBrawler.append(targetBrawler)
            self.player.unlocked_brawlers[str(targetBrawler)]["PowerPoints"] += reward
            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)

        brawlersOffset = powerPointsRange
        raritiesChoices = [unlockableBrawlersRare, unlockableBrawlersSuperRare, unlockableBrawlersEpic, unlockableBrawlersMegaEpic, unlockableBrawlersLegendary]
        probabilities = [0.45, 0.35, 0.15, 0.1, 0.05]
        filteredChoices = [(choice, prob) for choice, prob in zip(raritiesChoices, probabilities) if choice]
        raritiesChoices, probabilities = zip(*filteredChoices) if filteredChoices else ([], [])
        if not raritiesChoices:
            self.hasBrawler = False
        else:
            total_probability = sum(probabilities)
            normalized_probabilities = [p / total_probability for p in probabilities]
        
        if self.hasStarPower:
            starPoweredBrawlerID = random.choice(starPowerableBrawlers)
            #print(Characters.getBrawlerName(starPoweredBrawlerID))
            starPower = Cards.get_brawler_star_power(starPoweredBrawlerID)
            self.rewards.append(starPower)
            self.rewardNames.append("StarPower")
            self.rewardsTargetBrawler.append(starPoweredBrawlerID)
            brawlersOffset = powerPointsRange+1 if powerPointsRange > 0 else powerPointsRange
            self.player.unlocked_brawlers[str(starPoweredBrawlerID)]["StarPower"] = starPower

            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
        if self.hasBrawler:
            
            selectedRarity = random.choices(raritiesChoices, weights=normalized_probabilities, k=1)
            #print(selectedRarity)
            rewardedBrawler = random.choice(selectedRarity[0])
            #print(rewardedBrawler)
            self.rewards.append(rewardedBrawler)
            self.rewardNames.append("Brawler")
            self.rewardsTargetBrawler.append(0)
            brawlersOffset = powerPointsRange+1 if powerPointsRange > 0 else powerPointsRange
            self.player.unlocked_brawlers[str(self.rewards[brawlersOffset])] = {
                'CardID': Cards.get_brawler_unlock_by_character((self.rewards[brawlersOffset])),
                'Skins': [0],

                'selectedSkin': 0,
                'Trophies': 0,
                'HighestTrophies': 0,
                'PowerLevel': 0,
                'PowerPoints': 0,
                'State': 0,
                'StarPower': 0
            }

            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
        self.hasBonus = (random.randint(0, 5) == 2)
        if self.hasBonus:
            possibleBonuses = ["tickets", "gems", "tokens_doubler"]
            selectedBonus = random.choice(possibleBonuses)
            if selectedBonus == "tickets":
                self.rewards.append(random.choice([1, 2, 3, 5]))
                self.player.tickets += self.rewards[brawlersOffset + 1]
                self.updatedBonus = self.player.tickets
            elif selectedBonus == "gems":
                self.rewards.append(random.choice([3, 5, 6, 8, 12]))
                self.player.gems += self.rewards[brawlersOffset + 1]
                self.updatedBonus = self.player.gems
            elif selectedBonus == "tokens_doubler":
                self.rewards.append(random.choice(tokenDoublersRange))
                self.player.tokens_doubler += self.rewards[brawlersOffset + 1]
                self.updatedBonus = self.player.tokens_doubler
            self.rewardNames.append(selectedBonus)
            self.rewardsTargetBrawler.append(0)
            db.replaceValue(selectedBonus, self.updatedBonus)
        if self.boxID == 5:
            self.player.brawl_boxes -= 100
            db.replaceValue("brawl_boxes", self.player.brawl_boxes)
        if self.boxID == 4:
            self.player.big_boxes -= 10
            db.replaceValue("big_boxes", self.player.big_boxes)
        if self.boxID == 3:
            self.player.gems -= 80
            db.replaceValue("gems", self.player.gems)
        if self.boxID == 1:
            self.player.gems -= 30
            db.replaceValue("gems", self.player.gems)
    def getBoxType(self, boxID):
        if boxID in [0, 5]:
            return 10 # normal box case
        elif boxID in [1, 4]:
            return 12 # big box case
        elif boxID in [3]:
            return 11 # mega box case
        else:
            return boxID
        
    def itemType(self, item):
        if item == "gems":
            return 8
        elif item == "Coins":
            return 7
        elif item == "UpgradePoints":
            return 6
        elif item == "tickets":
            return 3
        elif item == "tokens_doubler":
            return 2
        elif item == "Brawler":
            return 1
        elif item == "Skin":
            return 9
        elif item == "StarPower":
            return 4
        else:
            print("[ERROR] Unknown item type!")
            return 0
        
    def encode(self):
        
        self.writeVInt(203) #command id that is supposed to be in AvailableServerCommands::encode(self)
        self.writeVInt(self.getBoxType(self.boxID)) # 10 = Normal box, 12 = big box, 11 = Mega box, 0,1,2,3,4,5 = rarity boxes (0 and 5 are unused and does'nt have any textures)
        self.writeVInt(1)
        self.writeVInt(0)
        #print(self.rewardNames)
        #print(self.rewards)
        #print(self.rewardsTargetBrawler)
        self.writeVInt(len(self.rewards))
        for reward in range(len(self.rewards)):
            self.writeVInt(self.rewards[reward] if self.rewardNames[reward] not in ["Brawler", "StarPower"] else 0) # reward amount
            if self.rewardsTargetBrawler[reward] == -1:
                self.rewardsTargetBrawler[reward] = 0
            self.writeDataReference(16, int(self.rewards[reward]) if self.rewardNames[reward] == "Brawler" else self.rewardsTargetBrawler[reward]) # reward csv id
            self.writeVInt(self.itemType(self.rewardNames[reward])) # reward id
            if self.rewardNames[reward] == "Skin":
                self.writeDataReference(29, self.rewards[reward]) # skin
            
            elif self.rewardNames[reward] == "StarPower":
                self.writeDataReference(23, self.rewards[reward])
            else:
                self.writeDataReference(0, 0)
            self.writeVInt(self.rewards[reward]) # hmm? upgrades related??
        if self.player.isTrophyRoad:
            self.writeVInt(self.player.trophyRoad + 1)
            self.player.isTrophyRoad = False
        else:
            self.writeVInt(0)
        LogicServerCommand.encode(self)
