from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Entries.LogicServerCommand import LogicServerCommand
class LogicUnlockSkinServerCommand(Writer):

    def __init__(self, client, player, fields):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.fields = fields

    def encode(self):
        db = DataBase(self.player)
        # 1 - brawler
        # 2 token doubler
        # 3 - ticket
        # 6 - power point
        # 7 - coin
        # 8 = gem
        self.writeVint(203)
        self.writeVint(100)
        self.writeVint(1)
        self.writeVint(1)
        
        self.writeVint(1) # reward count
        #One Reward
        self.writeVint(1) # item count
        self.writeDataReference(16, self.fields["brawler"])
        self.writeVint(9 if not self.fields["isBrawler"] else 1) # rewardID
        self.writeDataReference(29, self.fields["skin"][1])
        self.writeVint(0)
        self.player.unlocked_brawlers[str(self.fields["brawler"])]["Skins"].append(self.fields["skin"][1])
        db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
        # end
        self.writeVInt(0)
        LogicServerCommand.encode(self)
