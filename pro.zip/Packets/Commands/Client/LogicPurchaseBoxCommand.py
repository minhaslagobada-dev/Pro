from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand

class LogicPurchaseBoxCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        LogicCommand.decode(self, fields, False)
        #LogicCommand.parseFields(fields)
        
        self.box_id = self.readVInt()
        

    def process(self, crypter):
        db = DataBase(self.player)
        if self.box_id == 5 and self.player.brawl_boxes < 100:
            self.rewards = [0]
            self.rewardNames = ["Coins"]
            self.rewardsTargetBrawler = [0]
            self.player.gold += self.rewards[0]
            db.replaceValue("gold", self.player.gold)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.box_id == 4 and self.player.big_boxes < 10:
            self.rewards = [0]
            self.rewardNames = ["Coins"]
            self.rewardsTargetBrawler = [0]
            self.player.gold += self.rewards[0]
            db.replaceValue("gold", self.player.gold)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.box_id == 3 and self.player.gems < 80:
            self.rewards = [0]
            self.rewardNames = ["Coins"]
            self.rewardsTargetBrawler = [0]
            self.player.gold += self.rewards[0]
            db.replaceValue("gold", self.player.gold)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.box_id == 1 and self.player.gems < 30:
            self.rewards = [0]
            self.rewardNames = ["Coins"]
            self.rewardsTargetBrawler = [0]
            self.player.gold += self.rewards[0]
            db.replaceValue("gold", self.player.gold)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        else:
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, self.box_id)
            logicBoxDataCommand.getRewards()
            logicBoxDataCommand.send(crypter)
