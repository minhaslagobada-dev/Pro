from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
import random
from Files.CsvLogic.Skins import Skins
class LogicPurchaseOfferCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
       fields = {}
       LogicCommand.decode(self, fields, False)
        #LogicCommand.parseFields(fields)
        
       self.offer_index = self.readVInt()
       self.fields = {}


    def process(self, crypter):
        db = DataBase(self.player)
        offers = db.load_offers(self.player.token)
        self.offerInfos = offers["info"][str(self.offer_index)]
        if self.offerInfos["IsOfferPurchased"] == 1:
            return "kek"
        if self.offerInfos["OfferID"] in [0, 6, 15]:
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 10)
            logicBoxDataCommand.getRewards()
            logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 1:
            self.rewards = [self.offerInfos["Amount"]]
            self.rewardNames = ["Coins"]
            self.rewardsTargetBrawler = [0]
            self.player.gold += self.rewards[0]
            db.replaceValue("gold", self.player.gold)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 2:
            Value = self.offerInfos["Value"]
            unlockableBrawlersRare = []
            unlockableBrawlersSuperRare = []
            unlockableBrawlersEpic = []
            unlockableBrawlersMegaEpic = []
            unlockableBrawlersLegendary = []
            unlockableBrawlers = Characters.get_brawlers_id()
            for brawler in unlockableBrawlers:
                cardID = Cards.get_brawler_unlock_by_character(brawler) + 2
                rarity = Cards.get_brawler_rarity(cardID)
                if rarity == "rare":
                    unlockableBrawlersRare.append(brawler)
                elif rarity == "super_rare":
                    unlockableBrawlersSuperRare.append(brawler)
                elif rarity == "epic":
                    unlockableBrawlersEpic.append(brawler)
                elif rarity == "mega_epic":
                    unlockableBrawlersMegaEpic.append(brawler)
                elif rarity == "legendary":
                    unlockableBrawlersLegendary.append(brawler)
                elif rarity == "common":
                    pass
                else:
                    print(f"[ERROR] Unknown rarity {rarity}!")
            list = []
            if Value == 1:
                list = unlockableBrawlersRare
            elif Value == 2:
                list = unlockableBrawlersSuperRare
            elif Value == 3:
                list = unlockableBrawlersEpic
            elif Value == 4:
                list = unlockableBrawlersMegaEpic
            if len(list) == 0:
                return "kek"
            rewardedBrawler = random.choice(list)
            self.rewards = [rewardedBrawler]
            self.rewardNames = ["Brawler"]
            self.rewardsTargetBrawler = [0]
            self.player.unlocked_brawlers[str(rewardedBrawler)] = {
                'CardID': Cards.get_brawler_unlock_by_character((rewardedBrawler)),
                'Skins': [0],

                'selectedSkin': 0,
                'Trophies': 0,
                'HighestTrophies': 0,
                'PowerLevel': 0,
                'PowerPoints': 0,
                'State': 0,
                'StarPower': 0
            }

            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 3:
            self.rewards = [self.offerInfos["Target"][1]]
            self.rewardNames = ["Brawler"]
            self.rewardsTargetBrawler = [0]
            self.player.unlocked_brawlers[str(self.offerInfos["Target"][1])] = {
                'CardID': Cards.get_brawler_unlock_by_character((self.offerInfos["Target"][1])),
                'Skins': [0],

                'selectedSkin': 0,
                'Trophies': 0,
                'HighestTrophies': 0,
                'PowerLevel': 0,
                'PowerPoints': 0,
                'State': 0,
                'StarPower': 0
            }

            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 4:
            if self.offerInfos["Target"][1] not in Skins.get_skins_id():
                return "kek"
            self.fields["isBrawler"] = Skins.getIsDefaultSkin(self.offerInfos["Target"][1])
            self.fields["brawler"] = Skins.getBrawler(self.offerInfos["Target"][1])
            if self.fields["isBrawler"]:
                if self.fields["brawler"] in self.player.unlocked_brawlers:
                    return "kek"
                self.rewardNames = ["Brawler"]
                self.rewards = [self.fields["brawler"]]
                self.rewardsTargetBrawler = [0]
                self.player.unlocked_brawlers[str(self.rewards[0])] = {
                'CardID': Cards.get_brawler_unlock_by_character((self.rewards[0])),
                'Skins': [0],
                'selectedSkin': 0,
                'Trophies': 0,
                'HighestTrophies': 0,
                'PowerLevel': 0,
                'PowerPoints': 0,
                'State': 0,
                'StarPower': 0
            }
            
                db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
                logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
                logicBoxDataCommand.send(crypter)
            else:
                if self.fields["brawler"] not in self.player.unlocked_brawlers:
                    return "kek"
                self.rewardNames = ["Skin"]
                self.rewards = [self.offerInfos["Target"][1]]
                self.rewardsTargetBrawler = [0]
                self.player.unlocked_brawlers[str(self.fields["brawler"])]["Skins"].append(self.offerInfos["Target"][1])
                self.player.unlocked_brawlers[str(self.fields["brawler"])]["selectedSkin"] = self.offerInfos["Target"][1]
                db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
                logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
                logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 5:
            starPoweredBrawlerID = self.offerInfos["Target"][1]
            starPower = Cards.get_brawler_star_power(starPoweredBrawlerID)
            self.rewards = [starPower]
            self.rewardNames = ["StarPower"]
            self.rewardsTargetBrawler = [starPoweredBrawlerID]
            self.player.unlocked_brawlers[str(starPoweredBrawlerID)]["StarPower"] = starPower
        elif self.offerInfos["OfferID"] == 7:
            self.rewardNames = ["tickets"]
            self.rewards = [self.offerInfos["Amount"]]
            self.rewardsTargetBrawler = [0]
            self.player.tickets += self.rewards[0]
            db.replaceValue('tickets', self.player.tickets)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 8:
            self.rewards = [self.offerInfos["Amount"]]
            self.rewardNames = ["UpgradePoints"]
            self.rewardsTargetBrawler = [self.offerInfos["Target"][1]]
            self.player.unlocked_brawlers[str(self.offerInfos["Target"][1])]["PowerPoints"] += self.offerInfos["Amount"]
            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif self.offerInfos["OfferID"] == 9:
            self.rewardNames = ["tokens_doubler"]
            self.rewards = [self.offerInfos["Target"][1]]
            self.rewardsTargetBrawler = [0]
            self.player.tokens_doubler += self.rewards[0]
            db.replaceValue('tokens_doubler', self.player.tokens_doubler)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
            
        elif self.offerInfos["OfferID"] == 10:
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 11)
            logicBoxDataCommand.getRewards()
            logicBoxDataCommand.send(crypter)
            
        elif self.offerInfos["OfferID"] == 11:
            return "kek"
        
        elif self.offerInfos["OfferID"] == 12:
            return "kek"
        
        elif self.offerInfos["OfferID"] == 13:
            return "kek"
        
        elif self.offerInfos["OfferID"] == 14:
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 12)
            logicBoxDataCommand.getRewards()
            logicBoxDataCommand.send(crypter)
            
        elif self.offerInfos["OfferID"] == 16:
            return "kek"
        
        else:
            print("[ERROR] Unhandled type!")
            
        if self.offerInfos["Currency"] == 0:
            self.player.gems -= self.offerInfos["Price"]
            db.replaceValue("gems", self.player.gems)
        elif self.offerInfos["Currency"] == 1:
            self.player.gold -= self.offerInfos["Price"]
            db.replaceValue("gold", self.player.gold)
            
        offers["info"][str(self.offer_index)]["IsOfferPurchased"] = 1
        db.save_offers(self.player.token, offers)