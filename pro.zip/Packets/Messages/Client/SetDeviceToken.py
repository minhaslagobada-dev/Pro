from random import choice
from string import ascii_uppercase
import json

from Logic.Player import Players

from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand


class SetDeviceToken(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        fields["Bytes"] = self.readBytes(self.readInt())
        fields["Int"] = self.readInt()
        #LogicCommand.parseFields(fields)

    def process(self, crypter):
        pass