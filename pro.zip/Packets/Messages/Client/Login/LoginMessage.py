from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.UnknownServerPackets import UnknownServerPackets
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.PiranhaMessage import PiranhaMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Friend.FriendOnlineStatusEntryMessage import FriendOnlineStatusEntryMessage
from Packets.Messages.Server.Alliance.AllianceTeamsMessage import AllianceTeamsMessage
import time
class LoginMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.high_id = self.readInt()
        self.player.low_id = self.readInt()
        self.player.token = self.readString()

        self.major = self.readInt()
        self.minor = self.readInt()
        self.build = self.readInt()

        self.fingerprint_sha = self.readString()

        Unk1 = self.readString()
        self.player.deviceID = self.readString()
        Unk2 = self.readString()
        self.player.Device = self.readString()
        self.player.preferredLanguage = self.readDataReference()
        self.player.region = self.readString().split('-')[1]
        #print(self.player.region)

    def process(self, crypter):
        db = DataBase(self.player)
        if self.major != 12:
            self.player.err_code = 16
            LoginFailedMessage(self.client, self.player, "").send(crypter)


        if self.fingerprint_sha != self.player.patch_sha and self.player.patch:
            LoginFailedMessage(self.client, self.player, "").send(crypter)

        elif self.player.low_id != 0:
            try:
                db.getPlayerId()
                db.createAccount()
            except:
                pass
            LoginOkMessage(self.client, self.player).send(crypter)
            db.loadAccount()
            self.special_offer = json.load(open('special_offer.json'))
            self.hasSpecialOffer = self.special_offer["isEnabled"]
            offers = db.load_offers(self.player.token)
            offfers = offers["info"]
            for index in range(len(offfers)):
                if offers["info"][str(index)]["Timer"] < time.time() or (self.hasSpecialOffer and index == 0):
                    db.reroll_offer(self.player.token, index)
            OwnHomeDataMessage(self.client, self.player).send(crypter)
            db.loadGameroom()
            
            MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)
            def by_trophy(plr):
                return plr['trophies']
            db = DataBase(self.player)
            tokens = []
            for token in self.player.friends:
                tokens.append(token)
            players = db.getSpecifiedPlayers(tokens)
            players.sort(key = by_trophy, reverse=True)
            FriendListMessage(self.client, self.player, players).send(crypter)
            for player in players:
                FriendOnlineStatusEntryMessage(self.client, self.player, player["low_id"]).send(crypter)
            nextKey = db.getNextKey(self.player.club_id)
            self.player.lastSeenKey = nextKey
            AllianceStreamMessage(self.client, self.player, self.player.club_id, 0).send(crypter)
            AllianceTeamsMessage(self.client, self.player).send(crypter)
            

            if self.player.room_id > 0:
                try:
                    TeamGameroomDataMessage(self.client, self.player).send(crypter)
                    TeamStreamMessage(self.client, self.player, self.player.room_id).send(crypter)
                except:
                    pass
            
        else:
            
            #self.player.low_id = Helpers.randomID(self)
            self.player.high_id = 0
            self.player.token = Helpers.randomStringDigits(self)
            db.getPlayerId()
            db.createAccount()
            LoginOkMessage(self.client, self.player).send(crypter)
            OwnHomeDataMessage(self.client, self.player).send(crypter)
            MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)