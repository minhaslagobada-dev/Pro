from Packets.Messages.Server.Login.ServerHelloMessage import ServerHelloMessage
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.PiranhaMessage import PiranhaMessage

class ClientHelloMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes, serverStates):
        super().__init__(initial_bytes)
        self.player = player
        self.serverStates = serverStates
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["Protocol"] = self.readInt()
        self.fields["KeyVersion"] = self.readInt()
        self.fields["MajorVersion"] = self.readInt()
        self.fields["MinorVersion"] = self.readInt()
        self.fields["Build"] = self.readInt()
        self.fields["ContentHash"] = self.readString()
        self.fields["DeviceType"] = self.readInt()
        self.fields["AppStore"] = self.readInt()


    def process(self, crypter):
        ServerHelloMessage(self.client, self.player).send(crypter)
        if self.serverStates.maintenance:
            LoginFailedMessage(self.client, self.player, "", 10).send(crypter)
        elif self.fields["MajorVersion"] != 12:
            LoginFailedMessage(self.client, self.player, "", 10).send(crypter)
        else:
            pass