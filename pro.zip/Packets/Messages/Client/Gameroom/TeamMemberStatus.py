from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class TeamMemberStatus(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.player_status = self.readVInt()

    def process(self, crypter):
        db = DataBase(self.player)
        playerInfo = db.getPlayerInfo(self.player.low_id)
        playerInfo['status'] = self.player.player_status
        db.updateGameroomPlayerInfo(self.player.low_id, self.player.room_id, playerInfo)
        TeamGameroomDataMessage(self.client, self.player).send(crypter)