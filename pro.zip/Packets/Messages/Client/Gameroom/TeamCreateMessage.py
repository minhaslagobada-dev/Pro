from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
import random
from random import choice
from string import ascii_uppercase
import json
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
import time

class TeamCreateMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.mapSlot = self.readVInt()
        self.player.map_id = self.readVInt()
        self.roomType = self.readVInt()
        self.mapID = self.readVInt()

    def process(self, crypter):
        if self.player.room_id != 0:
            return "nuh uh"
        db = DataBase(self.player)
        #self.player.room_id = random.randint(0, 2147483647)
        db.getRoomId()
        db.replaceValue('room_id', self.player.room_id)
        if self.player.map_id > 100:
            self.player.map_id = 0 

        db.createGameroom(self.roomType, {"info": {"roomID": self.player.room_id, "messages": { "0": {"EventType": 4, "Event": 101, "Tick": 1, "PlayerID": self.player.low_id, "PlayerName": self.player.name, "Message": "", "promotedTeam": 0, "TimeStamp": time.time(), "targetID": self.player.low_id, "targetName": self.player.name}}}})
        #TeamGameroomDataMessage(self.client, self.player).send(crypter)
        #TeamStreamMessage(self.client, self.player, self.player.room_id).send(crypter)
