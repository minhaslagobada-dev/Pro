from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Alliance.AllianceEventMessage import AllianceEventMessage
from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage

from Packets.PiranhaMessage import PiranhaMessage


class TeamKickMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["playerID"] = self.readVLong()
        

    def process(self, crypter):
        db = DataBase(self.player)
        gameroomInfo = db.getGameroomInfo("info")
        gameroomInfo["players"][str(self.player.low_id)]["host"]
        if not gameroomInfo["players"][str(self.player.low_id)]["host"]:
            return "kek"
        
        # Removing member 
        playertoken = db.getTokenByLowId(self.fields["playerID"][1])
        db.removeGameroomPlayer(self.fields["playerID"][1], self.player.room_id, playertoken)
        db.addGameroomMsg(self.player.room_id, 4, self.player.low_id, self.player.name, "", 104, self.fields["playerID"][1], self.player.name)
        
        db.replaceOtherValue('room_id', 0, playertoken)