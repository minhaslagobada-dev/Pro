from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class TeamPostAdMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.boolTarget = self.readVInt()

    def process(self, crypter):
        db = DataBase(self.player)
        gamerooomInfo = db.getGameroomInfo("info")
        if self.boolTarget == 1:
            gamerooomInfo["advertiseToBand"] = not gamerooomInfo["advertiseToBand"]
            if gamerooomInfo["advertiseToBand"] and not gamerooomInfo["alreadyAdvertisedToBand"]:
                db.addMsg(self.player.club_id, 77, self.player.low_id, self.player.name, self.player.club_role, "", 0)
                gamerooomInfo["alreadyAdvertisedToBand"] = True
                db.updateGameroomInfo(gamerooomInfo["alreadyAdvertisedToBand"], self.player.room_id, "alreadyAdvertisedToBand")
            db.updateGameroomInfo(gamerooomInfo["advertiseToBand"], self.player.room_id, "advertiseToBand")
        elif self.boolTarget == 2:
            gamerooomInfo["advertiseToFriends"] = not gamerooomInfo["advertiseToFriends"]
            db.updateGameroomInfo(gamerooomInfo["advertiseToFriends"], self.player.room_id, "advertiseToFriends")
        else:
            print("[ERROR] Unknown target!")
        TeamGameroomDataMessage(self.client, self.player).send(crypter)
        