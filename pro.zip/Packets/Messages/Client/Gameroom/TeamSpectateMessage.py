from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Logic.Player import Players
from Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage

class TeamSpectateMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        self.fields["Unk1"] = self.readVInt()
        self.fields["Unk2"] = self.readVInt()
        self.fields["Unk3"] = self.readVInt()
        super().decode(self.fields)
        return self.fields

    def process(self, crypter):
        if self.player.room_id != 0:
            return "nuh uh"
        db = DataBase(self.player)
        #try:
        joined = db.joinGameroom(self.fields["Unk2"])
        if joined:
            db.connection.commit()
            self.player.room_id = self.fields["Unk2"]
            db.replaceValue('room_id', self.player.room_id)
            db.addGameroomMsg(self.player.room_id, 4, self.player.low_id, self.player.name, " ", 102, self.player.low_id, self.player.name)
            #TeamGameroomDataMessage(self.client, self.player).send(crypter)
        else:
            TeamErrorMessage(self.client, self.player, 6)

