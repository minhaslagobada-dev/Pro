from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Cards import Cards

from Packets.PiranhaMessage import PiranhaMessage


class TeamChangeMemberSettingsMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.unk = self.readVInt()
        self.csv_id = self.readVInt()
        self.csv_target = self.readVInt()

    def process(self, crypter):
        db = DataBase(self.player)
        playerInfo = db.getPlayerInfo(self.player.low_id)
        playerInfo["brawler_id"] = self.csv_target
        db.updateGameroomPlayerInfo(self.player.low_id, self.player.room_id, playerInfo)

        TeamGameroomDataMessage(self.client, self.player).send(crypter)