from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Files.CsvLogic.Locations import Locations
from Packets.PiranhaMessage import PiranhaMessage

class TeamSetLocationMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.csvID = self.readVInt()
        self.player.map_id = self.readVInt()
        self.roomType = 1

    def process(self, crypter):
        db = DataBase(self.player)
        if self.player.map_id not in Locations.getAllLocations():
            return "kek"
        db.updateGameroomInfo(self.player.map_id, self.player.room_id, "map_id")
        db.updateGameroomInfo(self.roomType, self.player.room_id, "room_type")
        TeamGameroomDataMessage(self.client, self.player).send(crypter)