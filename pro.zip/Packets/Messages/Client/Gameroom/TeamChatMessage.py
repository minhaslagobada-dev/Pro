from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from random import choice
from string import ascii_uppercase
import json
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class TeamChatMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.msg = self.readString()

    def process(self, crypter):
        db = DataBase(self.player)
        db.addGameroomMsg(self.player.room_id, 2, self.player.low_id, self.player.name, self.msg, 0)
        db.loadGameroom()
