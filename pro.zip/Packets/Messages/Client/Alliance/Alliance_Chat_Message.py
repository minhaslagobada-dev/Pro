from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from random import choice
from string import ascii_uppercase
import json
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class AllianceChatMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.msg = self.readString()

    def process(self, crypter):
        db = DataBase(self.player)
        db.addMsg(self.player.club_id, 2, self.player.low_id, self.player.name, self.player.club_role, self.msg, 0)
        db.loadClub(self.player.club_id)
        #nextKey = db.getNextKey(self.player.club_id)
        #AllianceChatServerMessage(self.client, self.player, self.player.club_id, nextKey+1).send(crypter)
