from Packets.Messages.Server.Alliance.AllianceMemberEntryMessage import AllianceMemberEntryMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Events.AllianceJoinOkMessage import AllianceJoinOkMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from random import choice
from string import ascii_uppercase
import json
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class Join_Message(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.club_high_id = self.readInt()
        self.player.club_id = self.readInt()

    def process(self, crypter):
        db = DataBase(self.player)
        self.player.club_role = 1
        db.replaceValue('club_role', 1)
        db.replaceValue('club_id', self.player.club_id)

        # Member adding
        db.addMember(self.player.club_id, self.player.token, 1)
        db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, self.player.club_role, "", 3, self.player.low_id, self.player.name)

        # Info
        AllianceJoinOkMessage(self.client, self.player).send(crypter)
        MyAllianceMessage(self.client, self.player, self.player.club_id).send(crypter)
        AllianceStreamMessage(self.client, self.player, self.player.club_id, 0).send(crypter)
        club =  db.loadClub(self.player.club_id)
        nextKey = db.getNextKey(self.player.club_id)
        AllianceChatServerMessage(self.client, self.player, self.player.club_id, nextKey+1).send(crypter)
        #AllianceMemberEntryMessage(self.client, self.player).sendToOthers()