from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage


class GoHomeFromOfflinePractiseMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        if self.player.tutorialState < 2:
            self.player.tutorialState += 1
        db = DataBase(self.player)
        db.replaceValue('tutorialState', self.player.tutorialState)
        OwnHomeDataMessage(self.client, self.player).send(crypter)