from Packets.Messages.Server.Battle.BattleResultShowdownMessage import BattleResultShowdownMessage
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Packets.Messages.Server.Battle.BattleResultDuoShowdownMessage import BattleResultDuoShowdownMessage
from random import choice
from string import ascii_uppercase
import json
from Packets.PiranhaMessage import PiranhaMessage
import time
from Database.DatabaseManager import DataBase
from Logic.EventData import EventData
from Files.CsvLogic.Locations import Locations


class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        self.fields = {}
        self.fields["isInRealGame"] = True if self.player.tutorialState == 2 else False
        self.fields["Victory"] = self.readVInt()
        self.fields["Result"] = self.readVInt()
        self.fields["Rank"] = self.readVInt()
        self.fields["EventSlotThing"] = self.readVInt()
        self.fields["Index"] = self.readVInt()
        print(self.fields["Index"])
        db = DataBase(self.player)
        eventData = db.loadEvents(1)
        
        if self.fields["EventSlotThing"] == 4 and self.player.lastEventTimeStamp != eventData["info"]["events"][str(self.fields["EventSlotThing"]-1)]["TimeStamp"]:
            eventData = db.loadEvents(2)
        mapid = eventData["info"]["events"][str(self.fields["EventSlotThing"]-1)]["ID"]
        self.fields["GameMode"] = EventData.getGameModeVariationBattleEnd(self,mapid)
        self.fields["HeroesCount"] = self.readVInt()
        self.fields["Heroes"] = []
        for i in range(self.fields["HeroesCount"]): self.fields["Heroes"].append({"Brawler": {"ID": self.readDataReference(), "SkinID": self.readDataReference(), "Trophies": 0, "PowerLevel": 1}, "Team": self.readVInt(), "IsPlayer": self.readBoolean(), "PlayerName": self.readString(), "LowID": self.player.low_id if i == 0 else 0})
        self.fields["Heroes"][0]["Brawler"]["Trophies"] = self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["Trophies"]
        self.fields["Heroes"][0]["Brawler"]["PowerLevel"] = self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["PowerLevel"] + (1 if self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["StarPower"] == 0 else 2)
        self.fields["receiveTime"] = time.time()
        #super().decode(self.fields)
        #return self.fields

    def process(self, crypter):
        if self.fields["receiveTime"] - self.player.lastRecieved < 10:
            print("[WARNING] WE MIGHT HAVE A SPAMMER")
            return "kek"
        self.player.lastRecieved = self.fields["receiveTime"]
        if self.fields["HeroesCount"] not in [6, 10]:
            return "kek"
        BattleResultMessage(self.client, self.player, self.fields).send(crypter)