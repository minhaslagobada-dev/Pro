from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class AskForFriendListMessage(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        def by_trophy(plr):
                return plr['trophies']
        db = DataBase(self.player)
        tokens = []
        for token, state in self.player.friends:
            tokens.append(token)
        players = db.getSpecifiedPlayers(tokens)
        players.sort(key = by_trophy, reverse=True)
        FriendListMessage(self.client, self.player, players).send(crypter)