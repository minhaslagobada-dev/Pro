from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Friend.Events.FacebookBindOKMessage import FacebookBindOKMessage
from Packets.Messages.Server.Friend.Events.FBAccountDisconnectedOKMessage import FBAccountDisconnectedOKMessage

from Packets.PiranhaMessage import PiranhaMessage

class FacebookConnect(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readVInt()
        self.player.FacebookID = self.readString()
        self.player.FacebookToken = self.readString()

    def process(self, crypter):
        self.player.IsFacebookLinked = 1
        #DataBase.replaceValue(self, 'isFBLinked', 1)
        #DataBase.replaceValue(self, 'facebookID', self.player.FacebookID)
        #DataBase.replaceValue(self, 'facebookToken', self.player.FacebookToken)
    
        FacebookBindOKMessage(self.client, self.player).send(crypter)