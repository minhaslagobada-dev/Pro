from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

from Packets.Messages.Server.Friend.Events.AddFriendFailedMessage import AddFriendFailedMessage
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage


class AddFriend(PiranhaMessage):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.HighID = self.readInt()
        self.LowID = self.readInt()

    def process(self, crypter):
        def by_trophy(plr):
                return plr['trophies']
        db = DataBase(self.player)
        newFriend = db.getTokenByLowId(self.LowID)
        self.player.friends[newFriend] = 2
        db.replaceValue("friends", self.player.friends)
        players = db.getSpecifiedPlayers([newFriend])
        for player in players:
            self.friends = player["friends"]
            self.friends[self.player.token] = 3
        db.replaceOtherValue("friends", self.friends, newFriend)
        players.sort(key = by_trophy, reverse=True)
        FriendListUpdateMessage(self.client, self.player, self.LowID, players).send(crypter)
        #AddFriendFailedMessage(self.client, self.player).send()