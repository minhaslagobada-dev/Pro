from Utils.Writer import Writer
from Entries.FriendEntry import FriendEntry
from Database.DatabaseManager import DataBase

class FriendListMessage(Writer):
    def __init__(self, client, player, players):
        super().__init__(client)
        self.id = 20105
        self.client = client
        self.players = players
        self.player = player
    
    def encode(self):
        self.indexOfPlayer = 1
        db = DataBase(self.player)
        self.writeInt(len(self.players))
        self.writeBoolean(True)
        
        self.writeInt(len(self.players)) # Friends Length
        for player in self.players:
            if player["low_id"] == self.player.low_id:
                self.indexOfPlayer = self.players.index(player) + 1
            FriendEntry.encode(self, player, db)
