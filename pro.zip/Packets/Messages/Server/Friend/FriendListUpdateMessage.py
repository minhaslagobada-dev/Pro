from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Entries.FriendEntry import FriendEntry

class FriendListUpdateMessage(Writer):

    def __init__(self, client, player, friendLowID, players):
        super().__init__(client)
        self.id = 20106
        self.player = player
        self.friendID = friendLowID
        self.players = players

    def encode(self):
        self.indexOfPlayer = 1
        db = DataBase(self.player)
        self.writeBoolean(True) # Player Count
        for player in self.players:
            if player["low_id"] == self.player.low_id:
                self.indexOfPlayer = self.players.index(player) + 1

            FriendEntry.encode(self, player, db)