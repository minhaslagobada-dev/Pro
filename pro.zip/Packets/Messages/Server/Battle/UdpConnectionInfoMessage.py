from Utils.Writer import Writer

class UdpConnectionInfoMessage(Writer):
    def __init__(self, client, player, device):
        super().__init__(client)
        self.id = 24112
        self.client = client
        self.player = player
        self.device = device

    def encode(self):
        self.writeVint(9349) # Port
        self.writeString("localhost") # IP
        self.writeBytes(b'0') # Session ID
        self.writeStringReference("localhost")
