from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class StartLoadingMessage(Writer):
    def __init__(self, client, player, device):
        super().__init__(client)
        self.id = 20559
        self.device = device
        self.client = client
        self.player = player

    def encode(self):
        DataBase.loadAccount(self)
        DataBase.loadMMPool(self, self.player.MapIndex)
        self.writeInt(6) # Player Count for the GameMode
        self.writeInt(0)
        self.writeInt(0)

        self.writeInt(6) # Players Count
        self.writeInt(0) # Player High ID
        self.writeInt(1) # Player Low ID
        self.writeString(self.matchmakedata["0"]["name"]) # Player Name
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeInt(30)

        self.writeScId(16, self.matchmakedata["0"]["brawlerID"]) # Selected Brawler
        self.writeVint(0) # Selected Skin
        self.writeBoolean(False)

        self.writeInt(0) # Player High ID
        self.writeInt(2) # Player Low ID
        self.writeString(self.matchmakedata["1"]["name"]) # Player Name
        self.writeVint(1) # Player Index
        self.writeVint(1) # Player Team
        self.writeVint(0)
        self.writeInt(30)

        self.writeScId(16, self.matchmakedata["1"]["brawlerID"]) # Selected Brawler
        self.writeVint(0) # Selected Skin
        self.writeBoolean(False)

        self.writeInt(0) # Player High ID
        self.writeInt(3) # Player Low ID
        self.writeString("3") # Player Name
        self.writeVint(2) # Player Index
        self.writeVint(0) # Player Team
        self.writeVint(0)
        self.writeInt(30)

        self.writeScId(16, 0) # Selected Brawler
        self.writeVint(0) # Selected Skin
        self.writeBoolean(False)

        self.writeInt(0) # Player High ID
        self.writeInt(4) # Player Low ID
        self.writeString("4") # Player Name
        self.writeVint(3)
        self.writeVint(1)
        self.writeVint(0)
        self.writeInt(30)

        self.writeScId(16, 0) # Selected Brawler
        self.writeVint(0) # Selected Skin
        self.writeBoolean(False)

        self.writeInt(0) # Player High ID
        self.writeInt(5) # Player Low ID
        self.writeString("5") # Player Name
        self.writeVint(4) # Player Index
        self.writeVint(1) # Player Team
        self.writeVint(0)
        self.writeInt(30)

        self.writeScId(16, 0) # Selected Brawler
        self.writeVint(0) # Selected Skin
        self.writeBoolean(False)

        self.writeInt(0) # Player High ID
        self.writeInt(6) # Player Low ID
        self.writeString("6") # Player Name
        self.writeVint(5) # Player Index
        self.writeVint(1) # Player Team
        self.writeVint(0)
        self.writeInt(30)

        self.writeScId(16, 0) # Selected Brawler
        self.writeVint(0) # Selected Skin
        self.writeBoolean(False)

        self.writeInt(6) # Player ID Count

        self.writeInt(0) # Player High ID
        self.writeInt(1) # Player Low ID

        self.writeInt(0) # Player High ID
        self.writeInt(2) # Player Low ID

        self.writeInt(0) # Player High ID
        self.writeInt(3) # Player Low ID

        self.writeInt(0) # Player High ID
        self.writeInt(4) # Player Low ID

        self.writeInt(0) # Player High ID
        self.writeInt(5) # Player Low ID

        self.writeInt(0) # Player High ID
        self.writeInt(6) # Player Low ID

        self.writeInt(1)
        self.writeVint(1)
        self.writeVint(1)
        self.writeVint(0) # Joystick State
        self.writeBoolean(True) # Battle Hints
        self.writeScId(15, 19) # Map ID 24 for brawl ball
        
        
