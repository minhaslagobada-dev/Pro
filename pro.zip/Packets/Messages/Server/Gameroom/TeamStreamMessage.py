from Database.DatabaseManager import DataBase
import json
from Utils.Writer2 import Writer
from Entries.StreamEntryFactory import StreamEntryFactory

class TeamStreamMessage(Writer):

    def __init__(self, client, player, roomLowID):
        super().__init__(client)
        # self.msg_content = msg_content
        self.id = 24131
        self.player = player
        self.roomLowID = roomLowID

    def encode(self):
     self.writeLogicLong(0, self.player.room_id)
     db = DataBase(self.player)
     msgCount = 0
     if self.roomLowID != 0:
        roomMessages = db.loadRoomMessages(self.roomLowID)
        if roomMessages != None:
           msgCount = len(roomMessages["info"]["messages"])
        self.writeVInt(msgCount)  # Message count
        #self.writeVInt(0)

        for index in range(msgCount):  # Loop through message indices
        #for index in range(0):
            messageKey = str(index)
            message = roomMessages["info"]["messages"][messageKey]
            self.writeVInt(message["EventType"])
            StreamEntryFactory.createStreamEntryByType(self, message)
     else:
        self.writeVInt(0)  # No messages