from Utils.Writer2 import Writer
import json
from Entries.StreamEntryFactory import StreamEntryFactory
from Database.DatabaseManager import DataBase

class TeamChatServerMessage(Writer):

    def __init__(self, client, player, roomLowID, tick):
        super().__init__(client)
        self.tick = tick
        self.roomLowID = roomLowID
        self.id = 24131
        self.player = player

    def encode(self):
        db = DataBase(self.player)
        msgCount = 0
        messageKey = str(0)
        if self.roomLowID != 0:
            roomMessages = db.loadRoomMessages(self.roomLowID)
            if roomMessages != None:
              for index in range(len(roomMessages["info"]["messages"])):
                  if roomMessages["info"]["messages"][str(index)]["Tick"] == self.tick-1:
                      messageKey = str(index)
              msgCount = 1
            self.writeLogicLong(0, self.roomLowID)
            self.writeVint(msgCount)  # Message count
        #self.writeVInt(0)

            for index in range(msgCount):  # Loop through message indices
        #for index in range(0):
                message = roomMessages["info"]["messages"][messageKey]
                self.writeVInt(message["EventType"])
                StreamEntryFactory.createStreamEntryByType(self, message)
        else:
            self.writeVint(0)  # No messages