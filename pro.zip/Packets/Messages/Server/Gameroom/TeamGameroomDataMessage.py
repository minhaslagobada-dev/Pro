from Utils.Writer2 import Writer
from Database.DatabaseManager import DataBase
from Logic.EventData import EventData
from Logic.LogicGamePlayUtil import LogicGamePlayUtil

class TeamGameroomDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.playerCount = 1
        self.playersData = {} 

    def encode(self):
            db = DataBase(self.player)
            gameroomInfo = db.getGameroomInfo("info")
            self.writeVInt(gameroomInfo["room_type"])  # Mode
            self.writeBoolean(gameroomInfo["room_type"] == 1) # practice with bots
            gameModeVariation = EventData.getGameModeVariation(self, gameroomInfo["map_id"])
            playerCountWithGameMode = LogicGamePlayUtil.getPlayerCountWithGameMode(gameModeVariation)
            self.writeVInt(playerCountWithGameMode) # max players
            self.writeLong(0, self.player.room_id)
            self.writeVInt(0)
            self.writeBoolean(gameroomInfo["advertiseToBand"])
            self.writeBoolean(gameroomInfo["advertiseToFriends"])
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeDataReference(15, gameroomInfo["map_id"])
            self.playerCount = gameroomInfo["player_count"]
            self.writeVint(self.playerCount)
            for player, values in gameroomInfo["players"].items():
                playerToken = db.getTokenByLowId(gameroomInfo["players"][player]["low_id"])
                playersData = (db.getSpecifiedPlayers([playerToken]))[0]
                self.writeBoolean(gameroomInfo["players"][player]["host"])  # Gameroom owner boolean
                self.writeLong(0, gameroomInfo["players"][player]["low_id"])  # player ID
                self.writeString(gameroomInfo["players"][player]["name"])  # Player name
                self.writeVint(0 if playerToken not in self.player.friends else self.player.friends[playerToken])  # friend list state
                self.writeDataReference(16, gameroomInfo["players"][player]["brawler_id"])  # Brawler ID
                self.writeDataReference(0, 1) #skin
                brawler_id = str(gameroomInfo["players"][player]["brawler_id"])
                self.writeVint(playersData["unlocked_brawlers"][brawler_id]["Trophies"])  # Trophies
                self.writeVint(playersData["unlocked_brawlers"][brawler_id]["HighestTrophies"])  # Highest trophies
                self.writeVint(playersData["unlocked_brawlers"][brawler_id]["PowerLevel"])  # Power level
                self.writeVint(gameroomInfo["players"][player]["status"] if playersData["player_status"] != 0 else 0)  # Player state
                self.writeBoolean(gameroomInfo["players"][player]["ready"])  # Is ready
                self.writeVint(gameroomInfo["players"][player]["team"])  # Team: 0 = Blue, 1 = Red
            self.writeVint(0) # array
            for unk in range(0):
                self.writeLong(0, gameroomInfo["players"][player]["low_id"])
                self.writeString("pour")
                self.writeVInt(1)
                self.writeVInt(0)

        