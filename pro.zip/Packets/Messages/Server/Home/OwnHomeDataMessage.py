from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Entries.LogicClientHome import LogicClientHome
from Logic.Shop import Shop
from Logic.EventSlots import EventSlots
from Logic.Milestones import Milestones
from Entries.LogicClientAvatar import LogicClientAvatar

class OwnHomeDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player
        self.milestones = Milestones

    def encode(self):
        
        db = DataBase(self.player)
        db.loadAccount()
        self.player.player_status = 2
        db.replaceValue("player_status", self.player.player_status)
        LogicClientHome.encode(self)
        LogicClientAvatar.encode(self)
        
        self.writeVInt(int(datetime.timestamp(datetime.now())))
        self.player.trophy_reward = 0
        self.player.key_reward = 0
        self.player.star_key_reward = 0
        db.replaceValue("key_reward", self.player.key_reward)
        db.replaceValue("trophy_reward", self.player.trophy_reward)
        db.replaceValue("star_key_reward", self.player.star_key_reward)
        db.replaceValue("region", self.player.region)
