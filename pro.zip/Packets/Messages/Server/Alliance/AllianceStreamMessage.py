from Database.DatabaseManager import DataBase
import json
from Utils.Writer2 import Writer
from Entries.StreamEntryFactory import StreamEntryFactory

class AllianceStreamMessage(Writer):

    def __init__(self, client, player, clubLowID, type):
        super().__init__(client)
        # self.msg_content = msg_content
        self.id = 24311
        self.player = player
        self.eventType = type
        self.clubLowID = clubLowID

    def encode(self):
     db = DataBase(self.player)
     msgCount = 0
     if self.clubLowID != 0:
        clubMessages = db.loadClubMessages(self.clubLowID)
        if clubMessages != None:
           msgCount = len(clubMessages["info"]["messages"])
        self.writeVint(msgCount)  # Message count
        #self.writeVInt(0)

        for index in range(msgCount):  # Loop through message indices
        #for index in range(0):
            messageKey = str(index)
            message = clubMessages["info"]["messages"][messageKey]
            self.writeVInt(message["EventType"])
            StreamEntryFactory.createStreamEntryByType(self, message)
     else:
        self.writeVint(0)  # No messages