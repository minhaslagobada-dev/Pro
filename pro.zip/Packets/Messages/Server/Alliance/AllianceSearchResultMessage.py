from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json


class AllianceSearchResultMessage(Writer):

    def __init__(self, client, player, fields, count):
        super().__init__(client)
        self.id = 24310
        self.player = player
        self.fields = fields
        self.count = count

    def encode(self):
        db = DataBase(self.player)
        db.countClubs(1, 100, 2, 30)
        self.writeString(self.fields["RequestedName"])
        self.writeVint(len(self.count))

        for i in self.count:
            self.writeInt(0)                                 # ClubHighID
            self.writeInt(i["clubID"])                                 # ClubLowID
            self.writeString(i["name"])                  # Club name

            self.writeVint(8)                                # BadgeID type
            self.writeVint(i["clubBadge"])                 # Club badge number

            self.writeVint(i["clubType"])                    # Club type

            self.writeVint(len(i["memberCount"]))             # Member count

            self.writeVint(i["trophies"])                # Trophies total
            self.writeVint(i["requiredTrophies"])          # Trophies needed
            self.writeVint(0)                                # Unknown

            self.writeString(i["region"])                # Region
            self.writeVint(i["onlineMembers"])             # Members online