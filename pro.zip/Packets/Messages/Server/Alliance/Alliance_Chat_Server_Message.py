from Utils.Writer2 import Writer
import json
from Entries.StreamEntryFactory import StreamEntryFactory
from Database.DatabaseManager import DataBase

class AllianceChatServerMessage(Writer):

    def __init__(self, client, player, clubLowID, tick):
        super().__init__(client)
        self.tick = tick
        self.clubLowID = clubLowID
        self.id = 24312
        self.player = player

    def encode(self):
        db = DataBase(self.player)
        msgCount = 0
        messageKey = str(0)
        if self.clubLowID != 0:
            clubMessages = db.loadClubMessages(self.clubLowID)
            if clubMessages != None:
              for index in range(len(clubMessages["info"]["messages"])):
                  if clubMessages["info"]["messages"][str(index)]["Tick"] == self.tick-1:
                      messageKey = str(index)
              msgCount = 1
            #self.writeVint(msgCount)  # Message count
        #self.writeVInt(0)

            for index in range(msgCount):  # Loop through message indices
        #for index in range(0):
                message = clubMessages["info"]["messages"][messageKey]
                self.writeVInt(message["EventType"])
                StreamEntryFactory.createStreamEntryByType(self, message)
        else:
            self.writeVint(0)  # No messages