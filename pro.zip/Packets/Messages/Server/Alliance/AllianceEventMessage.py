from Utils.Writer2 import Writer
import json


class AllianceEventMessage(Writer):

    def __init__(self, client, player, event):
        super().__init__(client)
        self.id = 24333
        self.player = player
        self.event = event

    def encode(self):
        self.writeVInt(self.event) # Event type