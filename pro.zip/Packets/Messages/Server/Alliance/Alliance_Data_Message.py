from Logic.Player import Players
from os import SEEK_CUR, curdir
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json
import time


class AllianceDataMessage(Writer):

    def __init__(self, client, player, clubHighID, clubLowID):
        super().__init__(client)
        self.id = 24301
        self.player = player
        self.clubHighID = clubHighID
        self.clubLowID = clubLowID

    def encode(self):
        db = DataBase(self.player)
        club = db.loadClub(self.clubLowID)

        if self.player.club_id != 0:
            self.writeVint(0)
        else:
            self.writeVint(2)

        # ClubID
        self.writeInt(0)                            # Club high id
        self.writeInt(self.clubLowID)               # Club low id

        self.writeString(club["info"]["name"])             # Club name

        # Badge
        self.writeVint(8)
        self.writeVint(club["info"]["clubBadge"])            # Club badge id

        # Club settings
        self.writeVint(club["info"]["clubType"])               # Club type [1 = open, 2 = invite only, 3 = closed]
        self.writeVint(club["info"]["onlineMembers"])       # Club members count

        # Club trophies
        self.writeVint(club["info"]["trophies"])           # Club total trophies
        self.writeVint(club["info"]["requiredTrophies"])     # Club required trophies

        # Club Info
        self.writeVint(0)
        self.writeVint(0)

        self.writeString(club["info"]["description"])      # Description

        # Members list
        self.writeVint(len(club["info"]["memberCount"]))        # Members list count

        for token in club["info"]["memberCount"]:
            memberData = db.getMemberData(token)

            self.writeInt(0)                                    # High Id
            self.writeInt(memberData["low_id"])                      # Low Id
            self.writeString(memberData["name"])
            self.writeVint(memberData["club_role"])                        # player club role | 0 = Nothing, 1 = Member, 2 = President, 3 = Senior, 4 = Vice President
            self.writeVint(0 if token not in self.player.friends else self.player.friends[token])                    # friend state
            self.writeVint(memberData["trophies"])                                   # trophies
            currentTime = int(time.time())
            
            self.writeVint(memberData["player_status"]) # Player states | 0 = last online 1 hour ago, 1 = battling, 2 = menu, 4 = matchmaking, 6 = last online 1 month ago, 7 = spectating, 8 = practicing
            if int(currentTime - memberData["last_connection_time"]) < 3600:
                self.writeVint(0)
            else:
                self.writeVint(round(currentTime - memberData["last_connection_time"])) # last seen timestamp
            self.writeScId(28, memberData["profile_icon"])