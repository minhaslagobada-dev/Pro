# Login
from Packets.Messages.Client.Login.ClientHelloMessage import ClientHelloMessage
from Packets.Messages.Client.Login.LoginMessage import LoginMessage
# Unknown
from Packets.Messages.Client.KeepAliveMessage import KeepAliveMessage
from Packets.LogicCommandManager import EndClientTurn
from Packets.Messages.Client.ChangeAvatarNameMessage import ChangeAvatarNameMessage
from Packets.Messages.Client.ClientCapabilities import ClientCapabilities
from Packets.Messages.Client.AnalyticsEventMessage import AnalyticsEventMessage
from Packets.Messages.Client.SetDeviceToken import SetDeviceToken
# Gameroom
from Packets.Messages.Client.Gameroom.TeamSetReadyMemberMessage import TeamSetReadyMemberMessage
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Packets.Messages.Client.Gameroom.TeamLeaveMessage import TeamLeaveMessage
from Packets.Messages.Client.Gameroom.TeamSetLocationMessage import TeamSetLocationMessage
from Packets.Messages.Client.Gameroom.TeamChangeMemberSettingsMessage import TeamChangeMemberSettingsMessage
from Packets.Messages.Client.Gameroom.TeamSetRankedLocationMessage import TeamSetRankedLocationMessage
from Packets.Messages.Client.Gameroom.TeamMemberStatus import TeamMemberStatus
from Packets.Messages.Client.Gameroom.TeamSpectateMessage import TeamSpectateMessage
from Packets.Messages.Client.Gameroom.TeamChatMessage import TeamChatMessage
from Packets.Messages.Client.Gameroom.TeamPostAdMessage import TeamPostAdMessage
from Packets.Messages.Client.Gameroom.TeamKickMessage import TeamKickMessage
# Battles
from Packets.Messages.Client.Battle.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Packets.Messages.Client.Battle.OnPlay import OnPlay
from Packets.Messages.Client.Battle.Cancel_Matchmaking import CancelMatchMaking
from Packets.Messages.Client.Battle.PlayAgainMessage import PlayAgainMessage
from Packets.Messages.Client.Battle.HomeBattleReplayMessage import HomeBattleReplayMessage
# Home
from Packets.Messages.Client.Home.GetLeaderboardMessage import GetLeaderboardMessage
from Packets.Messages.Client.Home.AvatarNameCheckRequestMessage import AvatarNameCheckRequestMessage
from Packets.Messages.Client.Home.PlayerStatusMessage import PlayerStatusMessage
from Packets.Messages.Client.Home.AskProfileMessage import AskProfileMessage
# Alliances
from Packets.Messages.Client.Alliance.Create_Message import Create_Message
from Packets.Messages.Client.Alliance.Ask_For_Alliance_Data_Message import AskForAllianceDataMessage
from Packets.Messages.Client.Alliance.Ask_Joinable_Alliances_Message import Ask_Joinable_Alliances_Message
from Packets.Messages.Client.Alliance.Join_Message import Join_Message
from Packets.Messages.Client.Alliance.Promote_Alliance_Member_Message import Promote_Alliance_Member_Message
from Packets.Messages.Client.Alliance.Leave_Message import Leave_Message
from Packets.Messages.Client.Alliance.Alliance_Chat_Message import AllianceChatMessage
from Packets.Messages.Client.Alliance.Edit_Settings_Message import Edit_Settings_Message
from Packets.Messages.Client.Alliance.Search_Message import Search_Message
from Packets.Messages.Client.Alliance.Send_Club_Mail_Message import SendClubMail
from Packets.Messages.Client.Alliance.RequestJoinAllianceMessage import RequestJoinAllianceMessage
from Packets.Messages.Client.Alliance.RespondToAllianceJoinRequestMessage import RespondToAllianceJoinRequestMessage
from Packets.Messages.Client.Alliance.KickAllianceMemberMessage import KickAllianceMemberMessage

# Friend
from Packets.Messages.Client.Friend.AddFriend import AddFriend
from Packets.Messages.Client.Friend.AskForFriendListMessage import AskForFriendListMessage
from Packets.Messages.Client.Friend.AskForFriendSuggestionsMessage import AskForFriendSuggestionsMessage
from Packets.Messages.Client.Friend.FacebookConnect import FacebookConnect
from Packets.Messages.Client.Friend.UnlinkFacebookAcount import UnlinkFacebookAcount

packets = {
    10100: ClientHelloMessage,
    10101: LoginMessage,
    10107: ClientCapabilities,
    10108: KeepAliveMessage,
    10110: AnalyticsEventMessage,
    10113: SetDeviceToken,
    10212: ChangeAvatarNameMessage,
    10502: AddFriend,
    10504: AskForFriendListMessage,
    10599: AskForFriendSuggestionsMessage,
    14102: EndClientTurn,
    14103: OnPlay,
    14106: CancelMatchMaking,
    14109: GoHomeFromOfflinePractiseMessage,
    14110: AskForBattleEndMessage,
    14113: AskProfileMessage,
    14114: HomeBattleReplayMessage,
    14177: PlayAgainMessage,
    14201: FacebookConnect,
    14211: UnlinkFacebookAcount,

    # Alliance
    14301: Create_Message,
    14302: AskForAllianceDataMessage,
    14303: Ask_Joinable_Alliances_Message,
    # 14304: Ask_Stream_Message,
    14305: Join_Message,
    14306: Promote_Alliance_Member_Message,
    14307: KickAllianceMemberMessage,
    14308: Leave_Message,
    14315: AllianceChatMessage,
    14316: Edit_Settings_Message,
    14317: RequestJoinAllianceMessage,
    14321: RespondToAllianceJoinRequestMessage,
    # 14322: Invite_Member_Message,
    # 14323: Accept_Join_Invite_Message,
    14324: Search_Message,
    14330: SendClubMail,

    # Friendly battle lobby
    14350: TeamCreateMessage,
    14353: TeamLeaveMessage,
    14363: TeamSetLocationMessage,
    14352: TeamKickMessage,
    14354: TeamChangeMemberSettingsMessage,
    14355: TeamSetReadyMemberMessage,
    14358: TeamSpectateMessage,
    14359: TeamChatMessage,
    14360: TeamPostAdMessage,
    14361: TeamMemberStatus,
    14362: TeamSetRankedLocationMessage,
    14363: TeamSetLocationMessage,
    14366: PlayerStatusMessage,

    14403: GetLeaderboardMessage,
    14600: AvatarNameCheckRequestMessage,
}
