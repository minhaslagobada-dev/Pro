from threading import Thread
from Logic.Battle import Battle
from Logic.GameModes import *
from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
#from Packets.Messages.Server.Battle.OnlineBattleResultMessage import BattleResultMessage
from Logic.BattleEnd import BattleEnd
from Database.DatabaseManager import DataBase
import time

class VisionUpdater(Thread):
    def __init__(self, client, player, device, index, lowid, ticks):
        Thread.__init__(self)
        self.client = client
        self.player = player
        self.device = device
        self.index = index
        self.low_id = lowid
        self.started = 0
        self.tick = ticks
        self.subtick = 0

    def run(self):
        self.started = 1
        Battle.battle_ticks[self.player.MapIndex - 1] = self.tick
        while self.started:
            self.startThreading()
            time.sleep(0.05)
        while self.started == 0:
            self.visionUpdate()
            time.sleep(0.05)

    def startThreading(self):
        if self.player.low_id == self.low_id:
            if Battle.battle_ticks[self.player.MapIndex - 1] <= 3080:
                Update(self.player.playermmindex, self.player.MapIndex - 1)
                VisionUpdateMessage(self.client, self.player, self.device, int(Battle.battle_ticks[self.player.MapIndex - 1]), self.low_id, self.player.MapIndex - 1).send()
            if Battle.battle_ticks[self.player.MapIndex - 1] == 3081 or Battle.battle_ticks[self.player.MapIndex - 1] == 3082:
                end = BattleEnd(self.client, self.player, self.device)
                end.start()
                self.started = 0
            elif Battle.battle_ticks[self.player.MapIndex - 1] > 3100:
                self.player.err_code = 1
                LoginFailedMessage(self.client, self.player, self.device, "Sorry, something wrong happened during online battle. Please restart game!", 1).send()
                self.started = 0
            Battle.battle_ticks[self.player.MapIndex - 1] += 0.5

    def visionUpdate(self):
        Update(self.player.playermmindex, self.player.MapIndex - 1)
        self.player.battleTicks = int(Battle.battle_ticks[self.player.MapIndex - 1])
        VisionUpdateMessage(self.client, self.player, self.device, int(Battle.battle_ticks[self.player.MapIndex - 1]), self.low_id, self.player.MapIndex - 1).send()
