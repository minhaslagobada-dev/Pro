from Logic.Battle import Battle
from Logic.Objects import *
from Logic.MapObjects import *
import math
import random
from Utils.BitStream import BitStream

class LogicGameObjectServer:

   def encode(stream, player, index):
     stream.writePositiveInt(player.playersX[index], 13) # x
     stream.writePositiveInt(player.playersY[index], 14) # y
     stream.writePositiveInt(0, 7) # player index
     stream.writePositiveInt(0, 12) # z
     stream.writePositiveInt(10, 4) # visibility