import time
from Database.DatabaseManager import DataBase
from threading import Thread
from Logic.Player import Players
#from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage

#from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.TeamMessage import TeamMessage
#from Packets.Messages.Server.Gameroom.TeamGameStartingMessage import TeamGameStartingMessage
#from Packets.Messages.Server.Battle.MatchMakingStatusMessage import MatchMakingStatusMessage

class Updater(Thread):
    def __init__(self, client, player, device):
        Thread.__init__(self)
        self.client = client
        self.device = device
        self.player = player

    def run(self):
        tick = 0
        DataBase.loadAccount(self)
        try:
            DataBase.GetmsgCount(self, self.player.club_low_id)
            while tick < 10:
                self.update()
                time.sleep(0.05)
                if self.player.msg_count_on_login == self.MessageCount:
                    break
                else:
                    tick = 6
                tick += 1
        except:
            pass

    def update(self):
        DataBase.loadAccount(self)
        try:
            if self.player.mmstat == 0:
                DataBase.GetmsgCount(self, self.player.club_low_id)
                #if self.player.msg_count_on_login != self.MessageCount:
                    #AllianceStreamMessage(self.client, self.player, self.player.club_low_id, 0).send()
            if self.player.club_low_id > 0:
                MyAllianceMessage(self.client, self.player, self.device, self.player.club_low_id).send()
            if self.player.room_id > 0:
                TeamMessage(self.client, self.player, self.device).send()
        except:
            pass
