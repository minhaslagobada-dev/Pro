import json
from Utils.Config import Config
from Utils.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards

class Players:
	try:
		config = open('config.json', 'r')
		content = config.read()
	except FileNotFoundError:
		print("Creating config.json...")
		Config.create_config()
		config = open('config.json', 'r')
		content = config.read()

	settings = json.loads(content)

	# Player data
	boxID = 0
	high_id = 0
	lastRecieved = 0
	lastEventTimeStamp = 0
	lastChaosMap = 0
	lastSeenKey = 0
	lastSeenGameroomKey = 0
	tutorialState = 2
	isTrophyRoad = False
	matchmakeSlot = None
	matchmakeState = 0
	preferredLanguage = [0, 0]
	trophyRoad = 1
	low_id = 0
	token = "None"
	player_status = 3
	last_connection_time = 0
	IsFacebookLinked = 0
	FacebookID = "None"
	FacebookToken = "None"
	box_id = 0
	friends = []
	ownSkinsArray = []
	map_id = 7
	MapIndex = 0
	maintenance_time = 777
	slot_index = 0
	room_id = 0
	brawler_id = 0
	skin_id = 0

	# Socket
	ClientDict = {}

	# Brawler data
	skins_id = Skins.get_skins_id()
	brawlers_id = Characters.get_brawlers_id()
	card_skills_id = Cards.get_spg_id()
	card_unlock_id = Cards.get_brawler_unlock()

	# General player (Brawler, Currency, etc..)
	unlocked_brawlers = {
        0: {'CardID': 0, 'Skins': [0], 'selectedSkin': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 0, 'PowerPoints': 0, 'State': 2, 'StarPower': 0}}
    # Player Data
	name = "Brawler"
	player_experience = 0
	profile_icon = 0
	name_color = 0
	do_not_distrub = 0
	brawl_boxes = settings['BrawlBoxTokens']
	big_boxes = settings['BigBoxTokens']
	highest_trophies = 0
	trophies = settings['Trophies']
	solo_wins = 0
	duo_wins = 0
	ThreeVSThree_wins = 0
	tokensdoubler = 0
	player_tokens = 0
	gems = settings['Gems']
	gold = settings['Gold']
	tickets = settings['Tickets']
	exp_points = settings['ExperiencePoints']
	region = "FR"
	tokens = 0
	# Battle
	
	availabletokens = 500
	trophy_reward = 0
	key_reward = 0
	star_key_reward = 0
    
	# "Online" Battle:
	battle_Tick = 0
    

	# Alliances
	club_high_id = 0
	club_id = 0
	club_role = 0

	# Message stuff...
	update_url = settings['UpdateUrl']
	patch_url = settings['PatchUrl']
	patch_sha = Fingerprint.loadFinger("GameAssets/fingerprint.json")

	err_code = 7
	maintenance = False
	patch = False

	if settings['Patch']:
		error_code = 7
		patch = True

	if settings['Maintenance']:
		err_code = 10
		maintenance = True

	# Chat data
	message_tick = 0
	bot_message_tick = 0
    # Friendly game (Teams, info, result)
	battle_result = 0
	game_type = 0
	rank = 0
	team = 0
	isReady = False
	result = 16

	bot1 = 0
	bot1_n = None
	bot2 = 0
	bot2_n = None
	bot3 = 0
	bot3_n = None
	bot4 = 0
	bot4_n = None
	bot5 = 0
	bot5_n = None

	def CreateNewBrawlersList():
		Players.BrawlersUnlockedState = {}
		for id in Players.brawlers_id:
			if id == 0:
				Players.BrawlersUnlockedState[str(id)] = 1
			else:
				Players.BrawlersUnlockedState[str(id)] = 0
		return Players.BrawlersUnlockedState

	def __init__(self, device):
		self.device = device
