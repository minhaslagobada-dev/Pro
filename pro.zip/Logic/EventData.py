from Files.CsvLogic.Locations import Locations
from Utils.Writer import Writer
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
import time

class EventData:
    def getGameModeVariation(self, location):
     variationString = Locations().GetGameModeString(location)
     if variationString == "CoinRush":
        gameModeVariation = 0
     elif variationString == "AttackDefend":
        gameModeVariation = 2
     elif variationString == "BossFight":
        gameModeVariation = 7
     elif variationString == "BountyHunter":
        gameModeVariation = 3
     elif variationString == "Artifact":
        gameModeVariation = 4
     elif variationString == "LaserBall":
        gameModeVariation = 5
     elif variationString == "BattleRoyale":
        gameModeVariation = 6
     elif variationString == "BattleRoyaleTeam":
        gameModeVariation = 9
     elif variationString == "Survival":
        gameModeVariation = 8
     else:
        print("[ERROR] Wrong game mode!")
        gameModeVariation = -1
        
    def getGameModeVariationBattleEnd(self, location):
     variationString = Locations().GetGameModeString(location)
     if variationString == "CoinRush":
        gameModeVariation = 0
     elif variationString == "AttackDefend":
        gameModeVariation = 0
     elif variationString == "BossFight":
        gameModeVariation = 4
     elif variationString == "BountyHunter":
        gameModeVariation = 0
     elif variationString == "Artifact":
        gameModeVariation = 0
     elif variationString == "LaserBall":
        gameModeVariation = 0
     elif variationString == "BattleRoyale":
        gameModeVariation = 2
     elif variationString == "BattleRoyaleTeam":
        gameModeVariation = 5
     elif variationString == "Survival":
        gameModeVariation = 4
     else:
        print("[ERROR] Wrong game mode!")
        gameModeVariation = -1
     return gameModeVariation
    def encode(self: Writer, index, state):
         db = DataBase(self.player)
         eventData = db.loadEvents(state)

         event = eventData["info"]["events"][str(index)]
    
         self.writeVInt(index + 1)  # type
         self.writeVInt(index + 1)  # slot index
         self.writeVInt((event["TimeStamp"] - int(time.time())))  # time left before event opens (set to 0 for active events array to disable it)
         self.writeVInt((event["TimeStamp"] - int(time.time())))  # time left
         self.writeVInt(event["Tokens"])  # tokens
         self.writeDataReference(15, event["ID"])
         self.writeVInt(2)
         self.writeString("HIIIIIIIIIIIIIIII!")  # Add appropriate string content
         self.writeVint(1)
         modifiers = []
         for key, repeat_count in event["Modifier"].items():
            modifiers.extend([int(key)] * repeat_count) 
         if 0 in modifiers:
            modifiers = []
         self.writeVint(len(modifiers))  # modifiers array length
         for modifier in modifiers:
            self.writeVint(modifier)  # Write each modifier
         if index == 4:
            self.player.lastChaosMap = event["ID"]
         self.player.lastEventTimeStamp = event["TimeStamp"]