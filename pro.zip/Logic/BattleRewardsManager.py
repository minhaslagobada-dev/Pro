import json
from Logic.Milestones import Milestones


class BattleRewardsManager:
    def __init__(self, player, db):
        self.player = player
        self.db = db
        self.milestones = Milestones()

    def get_trophy_modifiers(self, trophies):
        ranges = [
            (0, 29, (0, 0, 6)),
            (30, 59, (-1, 0, 6)),
            (60, 99, (-2, 0, 6)),
            (100, 139, (-2, 0, 5)),
            (140, 219, (-3, 0, 5)),
            (220, 299, (-4, 0, 5)),
            (300, 499, (-5, 0, 5)),
            (500, 599, (-6, 0, 5)),
            (600, 699, (-7, 0, 4)),
            (700, 799, (-7, 0, 3)),
            (800, 899, (-8, 0, 3)),
            (900, float("inf"), (-9, 0, 2)),
        ]
        for low, high, modifiers in ranges:
            if low <= trophies <= high:
                return modifiers
        return (0, 0, 0)

    def get_solo_trophy_modifiers(self, trophies):
        trophy_ranges = [
            (0, 29, [8, 7, 6, 5, 5, 4, 3, 2, 1, 0]),
            (30, 59, [8, 7, 6, 4, 3, 2, 0, -1, -2, -4]),
            (60, 99, [8, 7, 5, 4, 3, 1, 0, -2, -3, -4]),
            (100, 139, [7, 6, 5, 3, 2, 1, -1, -2, -3, -4]),
            (140, 219, [7, 6, 4, 3, 2, 0, -1, -3, -4, -5]),
            (220, 299, [7, 6, 4, 3, 1, 0, -2, -3, -4, -5]),
            (300, 499, [7, 6, 4, 2, 1, -1, -2, -4, -6, -7]),
            (500, 599, [6, 5, 3, 2, 0, -2, -3, -4, -6, -7]),
            (600, 699, [5, 4, 3, 1, -1, -2, -3, -4, -6, -7]),
            (700, float("inf"), [5, 3, 2, 1, -1, -2, -4, -5, -6, -7]),
        ]

        for low, high, rank_trophies in trophy_ranges:
            if low <= trophies <= high:
                return rank_trophies
        return [0] * 10

    def process_rewards(self, fields):
        self.fields = fields
        self.rank = self.fields["Rank"]
        self.brawler_trophies = self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["Trophies"]
        self.brawler_trophies_in_rank = self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["HighestTrophies"]
        self.hasStarKey = False
        if self.fields["GameMode"] == 2:
            self.rank_trophies = self.get_solo_trophy_modifiers(self.brawler_trophies)
            if self.fields["Rank"] <= 4:
                self.hasStarKey = True
        elif self.fields["GameMode"] == 5:
            self.rank_trophies = self.get_duo_trophy_modifiers(self.brawler_trophies)
            if self.fields["Rank"] <= 2:
                self.hasStarKey = True
        else:
            self.rank_trophies = self.get_trophy_modifiers(self.brawler_trophies)
            self.rank = self.fields["Victory"]
            if self.fields["Victory"] == 0:
                self.hasStarKey = True

        

        # Rewards per rank
        if self.fields["GameMode"] == 2:
            self.exp_rewards = [0, 1, 2, 3, 4, 5, 6, 9, 12, 15]
            self.token_rewards = [0, 2, 4, 6, 8, 12, 16, 22, 28, 34]
        elif self.fields["GameMode"] == 5:
            self.exp_rewards = [0, 2, 4, 8, 14]
            self.token_rewards = [0, 4, 8, 20, 32]

        else:
            self.exp_rewards = [4, 6, 8]
            self.token_rewards = [10,15,20]
            

        # Determine rewards
        self.trophies_gain = self.rank_trophies[self.rank - 1] if self.player.tutorialState == 2 else 0
        self.experience_gain = self.exp_rewards[self.rank - 1] if self.player.tutorialState == 2 else 0
        self.tokens_gain = self.token_rewards[self.rank - 1] if self.player.tutorialState == 2 else 0
        if self.fields["Heroes"][0]["IsPlayer"]:
            self.experience_gain += 10 if self.player.tutorialState == 2 else 0
            self.star_player_exp = 10 if self.player.tutorialState == 2 else 0
            self.exp_rewards_array = {0: self.experience_gain, 8: self.star_player_exp}
        else:
            self.star_player_exp = 0
            self.exp_rewards_array = {0: self.experience_gain}

        # Token doubler handling
        self.doubled_tokens = min(self.tokens_gain, self.player.tokensdoubler)
        self.remaining_tokens = self.player.tokensdoubler - self.doubled_tokens
        self.total_tokens = self.tokens_gain + self.doubled_tokens

        # Apply rewards
        self.milestonesRewardRank = 0
        self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["Trophies"] += self.trophies_gain
        if self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["HighestTrophies"] < self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["Trophies"]:
            self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["HighestTrophies"] = self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["Trophies"]
        for milestone in self.milestones.rankTrophies:
            if self.brawler_trophies < milestone and self.player.unlocked_brawlers[str(self.fields["Heroes"][0]["Brawler"]["ID"][1])]["Trophies"] >= milestone:
                self.milestonesRewardRank = 10

        if self.player.tutorialState == 2:
            if self.hasStarKey:
                self.player.starkeysReward = 1
                self.player.big_boxes += 1
            if self.fields["GameMode"] == 2:
                self.player.solo_wins += 1
                self.db.replaceValue("solo_wins", self.player.solo_wins)
            elif self.fields["GameMode"] == 5:
                self.player.duo_wins += 1
                self.db.replaceValue("duo_wins", self.player.duo_wins)
            else:
                self.player.three_vs_three_wins += 1
                self.db.replaceValue("three_vs_three_wins", self.player.three_vs_three_wins)
            self.player.player_experience += self.experience_gain + self.star_player_exp
            self.player.tokensdoubler = self.remaining_tokens
            self.player.brawl_boxes += self.total_tokens
            self.player.trophies += self.trophies_gain
            if self.player.trophies > self.player.highest_trophies:
                self.player.highest_trophies = self.player.trophies
            self.player.trophy_reward = self.trophies_gain
            self.player.key_reward = self.total_tokens
            self.player.star_key_reward = 1 if self.hasStarKey else 0
            self.db.replaceValue("key_reward", self.player.key_reward)
            self.db.replaceValue("trophy_reward", self.player.trophy_reward)
            self.db.replaceValue("star_key_reward", self.player.star_key_reward)
            self.db.replaceValue("unlocked_brawlers", self.player.unlocked_brawlers)
            self.db.replaceValue("player_experience", self.player.player_experience)
            self.db.replaceValue("tokens_doubler", self.player.tokensdoubler)
            self.db.replaceValue("brawl_boxes", self.player.brawl_boxes)
            self.db.replaceValue("big_boxes", self.player.big_boxes)
            self.db.replaceValue("trophies", self.player.trophies)
            self.db.replaceValue("highest_trophies", self.player.highest_trophies)
        else:
           pass
        return {"tokens_gain": self.tokens_gain, "trophies_gain": self.trophies_gain, "doubled_tokens": self.doubled_tokens, "remaining_tokens": self.remaining_tokens, "exp_rewards_array": self.exp_rewards_array, "brawler_trophies": self.brawler_trophies, "brawler_trophies_for_rank": self.brawler_trophies_in_rank, "experience": self.experience_gain, "star_player_exp": self.star_player_exp, "hasStarKey": self.hasStarKey}
    

    def get_duo_trophy_modifiers(self, trophies):
        trophy_ranges = [
            (0, 29, [7, 5, 4, 2, 0]),
            (30, 59, [7, 5, 2, -1, -3]),
            (60, 99, [7, 4, 2, -1, -4]),
            (100, 139, [6, 4, 1, -1, -4]),
            (140, 219, [6, 4, 1, -2, -5]),
            (220, 499, [6, 3, 0, -3, -6]),
            (500, 599, [6, 3, 0, -4, -6]),
            (600, 699, [4, 2, -1, -4, -6]),
            (700, 799, [3, 1, -1, -4, -6]),
            (800, 899, [3, 1, -2, -5, -7]),
            (900, float("inf"), [2, 0, -3, -5, -7]),
        ]

        for low, high, rank_trophies in trophy_ranges:
            if low <= trophies <= high:
                return rank_trophies
        return [0] * 5

    