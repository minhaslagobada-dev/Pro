from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots
from Logic.Shop import Shop
from Entries.LogicDailyData import LogicDailyData
from Entries.LogicConfData import LogicConfData

class LogicClientAvatar:
    def encode(self: Writer):
        self.writeVInt(self.player.high_id) #HighID
        self.writeVInt(self.player.low_id) #LowID

        self.writeVInt(self.player.high_id) #HighID
        self.writeVInt(self.player.low_id) #LowID

        self.writeVInt(self.player.high_id) #HighID
        self.writeVInt(self.player.low_id) #LowID

        self.writeString(self.player.name)
        self.writeBoolean(self.player.name != "Brawler")  # namesetbyuser

        self.writeString()

        self.writeVInt(8)  # Commodity count
        

        self.writeVInt(len(self.player.unlocked_brawlers) + 3)

        for key, unlock_id in self.player.unlocked_brawlers.items():
            self.writeVInt(23)
            self.writeVInt(unlock_id["CardID"])
            self.writeVInt(1)

        self.writeVInt(5)
        self.writeVInt(1)
        self.writeVInt(self.player.brawl_boxes) #Brawl Box tokens

        self.writeVInt(5)
        self.writeVInt(8)
        self.writeVInt(self.player.gold) #Gold

        self.writeVInt(5)
        self.writeVInt(9)
        self.writeVInt(self.player.big_boxes) #Big Box tokens

        # Brawlers Trophies array
        self.writeVInt(len(self.player.unlocked_brawlers))  # brawlers count
        for key, brawler_id in self.player.unlocked_brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["Trophies"])

        # Brawlers Trophies for Rank array
        self.writeVInt(len(self.player.unlocked_brawlers))  # brawlers count
        for key, brawler_id in self.player.unlocked_brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["HighestTrophies"])

        self.writeVInt(0)  # array

        # Brawlers Upgrade Points array
        self.writeVInt(len(self.player.unlocked_brawlers))  # brawlers count
        for key, brawler_id in self.player.unlocked_brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["PowerPoints"])

        # Brawlers Power Level array
        self.writeVInt(len(self.player.unlocked_brawlers))  # brawlers count
        for key, brawler_id in self.player.unlocked_brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(brawler_id["PowerLevel"])

        # Star Powers array
        self.writeVInt(len(self.player.unlocked_brawlers))  # brawlers count
        for key, brawler_id in self.player.unlocked_brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(1 if brawler_id["StarPower"] != 0 else 0)
            
        # brawlers seen array
        self.writeVInt(len(self.player.unlocked_brawlers))  # brawlers count
        for key, brawler_id in self.player.unlocked_brawlers.items():
            self.writeDataReference(16, int(key))
            self.writeVInt(0)

         
        
		
        
        self.writeVInt(self.player.gems)  # Player Gems
        self.writeVInt(self.player.gems)  # Free Gems
        self.writeVInt(self.player.player_experience) # Tips Related
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(self.player.tutorialState)