from Utils.Writer2 import Writer
class BattleLogPlayerEntry:
    
    def encode(ByteStream: Writer, player):
        ByteStream.writeVInt(69) # most likely the index
        ByteStream.writeLong(0, player + 1) # ids
        ByteStream.writeVInt(5)
        ByteStream.writeBoolean(True)
        ByteStream.writeString("Primo invasion :demon:") # name
        ByteStream.writeDataReference(16, player) # brawla
        ByteStream.writeVInt(669) # prob trophies on brawlers
        ByteStream.writeVInt(1) # prob power level
        ByteStream.writeVInt(2) # idk
