from Utils.Writer import Writer
from Entries.PlayerDisplayData import PlayerDisplayData
import time
from Entries.AllianceTeamEntry import AllianceTeamEntry

class FriendOnlineStatusEntry:
    
    def encode(ByteStream: Writer, lowID, playerData):
        ByteStream.writeLong(0, lowID) # FriendID?
        currentTime = int(time.time())
        ByteStream.writeVint(playerData["player_status"]) # Player states | 0 = last online 1 hour ago, 1 = battling, 2 = menu, 4 = matchmaking, 6 = last online 1 month ago, 7 = spectating, 8 = practicing
        if int(currentTime - playerData["last_connection_time"]) < 3600:
                ByteStream.writeVint(0)
        else:
                ByteStream.writeVint(round(currentTime - playerData["last_connection_time"])) # last seen timestamp
        ByteStream.writeBoolean(False) # Is in gameroom
        if False:
            AllianceTeamEntry.encode(ByteStream)
        ByteStream.writeBoolean(False)