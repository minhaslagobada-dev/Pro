from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer

class LogicGemOffer:
    def encode(self: Writer, item, amount):
         self.writeVInt(item['OfferID']) #offer id
         self.writeVInt(item["Amount"]) # amount
         self.writeDataReference(item["Target"][0], item["Target"][1]) # brawler id
         self.writeVInt(item['Value']) #value
         