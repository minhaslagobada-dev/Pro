import logging
import socket
import time
from threading import Thread, Event

from Logic.Device import Device
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Core.Crypto import Crypto
from serverStates import serverStates
from Database.DatabaseManager import DataBase

logging.basicConfig(filename="errors.log", level=logging.INFO, filemode="w")

def log_info(*args):
    print("[INFO]", *args)


class Server(Thread):
    def __init__(self, ip: str, port: int, serverStates):
        super().__init__()
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.port = port
        self.ip = ip
        self.serverStates = serverStates
        self._stop_event = Event()

    def run(self):
        self.server.bind((self.ip, self.port))
        log_info(f"Server started! Ip: {self.ip}, Port: {self.port}")
        self.server.listen()

        while self.serverStates.running:
            try:
                self.server.settimeout(1)
                client, address = self.server.accept()
                log_info(f"New connection! Ip: {address[0]}")
                ClientThread(client, address, self.serverStates).start()
            except socket.timeout:
                continue
            except Exception as e:
                logging.error(f"Error accepting client: {e}")

    def stop(self):
        self.serverStates.running = False
        self.server.close()
        log_info("Server stopped.")


class ClientThread(Thread):
    def __init__(self, client, address, serverStates):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)
        self.serverStates = serverStates
        self._stop_event = Event()
        self.serverStates.player = self.player

    def recvall(self, length: int):
        data = b""
        while len(data) < length:
            s = self.client.recv(length - len(data))
            if not s:
                raise ConnectionError("Receive Error!")
            data += s
        return data

    def run(self):
        crypter = Crypto()
        last_packet = time.time()
        db = DataBase(self.player)

        try:
            while self.serverStates.running:
                header = self.client.recv(7)

                
                eventData = db.loadEvents(1)
                event = eventData["info"]["events"][str(0)]
                if event["TimeStamp"] < time.time():
                    db.rerollEvents()

                if len(header) > 0:
                    last_packet = time.time()
                    packet_id = int.from_bytes(header[:2], "big")
                    length = int.from_bytes(header[2:5], "big")

                    data = self.recvall(length)
                    pdata = crypter.decrypt(packet_id, data)

                    if packet_id in packets:
                        if packet_id == 10100:
                            message = packets[packet_id](self.client, self.player, pdata, self.serverStates)
                        else:
                            message = packets[packet_id](self.client, self.player, pdata)

                        message.decode()
                        message.process(crypter)
                    else:
                        log_info(f"Packet not handled! Id: {packet_id}")

                # Timeout
                if time.time() - last_packet > 10:
                    log_info(f"Ip: {self.address[0]} disconnected!")
                    self.player.player_status = 0
                    db.replaceValue("player_status", self.player.player_status)
                    self.player.last_connection_time = time.time()
                    db.replaceValue("last_connection_time", self.player.last_connection_time)
                    self.client.close()
                    break

        except Exception as e:
            log_info(f"Error with client {self.address[0]}: {e}")
            self.client.close()



if __name__ == "__main__":
    states = serverStates()
    states.running = True
    states.maintenance = False

    server = Server("0.0.0.0", 9339, states)
    server.start()