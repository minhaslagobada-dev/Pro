
class serverStates:
	maintenance = False
	maintenanceTime = 3600
	bannedIps = []
	bannedAccountIds = []
	running = True
	player = True