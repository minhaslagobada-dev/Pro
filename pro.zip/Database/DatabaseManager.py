import sqlite3
import json
import time
import random
from Files.CsvLogic.Locations import Locations
import datetime 
from datetime import datetime, timedelta
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
class DataBase:

    def __init__(self, player):
        self.player = player
        self.connection = sqlite3.connect('database.db')
        self.cursor = self.connection.cursor()
        self._initialize_tables()

    def _initialize_tables(self):
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS Matchmake (
            slot INTEGER PRIMARY KEY,
            data TEXT
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS PlayerOffers (
            PlayerToken TEXT PRIMARY KEY,
            Offers TEXT NOT NULL
        )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Players (
                token TEXT PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Gamerooms (
                room_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Clubs (
                club_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS ClubChats (
                club_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS GameroomChats (
                room_id INTEGER PRIMARY KEY,
                data TEXT
            )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS Events (
            state INTEGER PRIMARY KEY,
            data TEXT
        )
        ''')
        self.connection.commit()

    def loadAccount(self):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            for key, value in playerData.items():
                setattr(self.player, key, value)
    def load_offers(self, player_token):
        query = "SELECT Offers FROM PlayerOffers WHERE PlayerToken = ?"
        self.cursor.execute(query, (player_token,))
        result = self.cursor.fetchone()
        if result:
            data = json.loads(result[0])
            return data#.get("info", {})
        return {}

    def initialize_player_offers(self, player_token):
        self.special_offer = json.load(open('special_offer.json'))
        self.hasSpecialOffer = self.special_offer["isEnabled"]
        unlockedBrawlers = []
        unlockableBrawlers = Characters.get_brawlers_id()
        for key, brawlerID in self.player.unlocked_brawlers.items():
                unlockedBrawlers.append(int(key))
                unlockableBrawlers.remove(int(key))
        unlockedBrawlersNotMaxed = []
        for brawler in unlockedBrawlers:
                if self.player.unlocked_brawlers[str(brawler)]["PowerPoints"] < 1410:
                    unlockedBrawlersNotMaxed.append(brawler)
        brawlersPrice = [0, 30, 80, 170, 350, 0]
        selectedRarity = random.randint(1, 4)
        brawlersThing = 5 if len(unlockedBrawlersNotMaxed) >= 5 else len(unlockedBrawlersNotMaxed)
        targetBrawlers = random.sample(unlockedBrawlersNotMaxed, brawlersThing)
        default_offers = {"info": {}}
        for i in range(2 + brawlersThing):
            powerPoints = random.randint(6, 20)
            offer = {
                "OfferID": 4 if i == 0 else 0 if i == 1 else 2 if i == 2 else 8, 
                "Target": [29, Skins.getNonDefaultSkins()] if i == 0 else [0, 0] if i in [1, 2] else [16, targetBrawlers[i-2]],
                "Value": 1 if i in [0, 1] else selectedRarity if i == 2 else powerPoints*2,  # Random Value
                "Amount": 1 if i in [0, 1, 2] else powerPoints,
                "Currency": 0 if i in [0, 1, 2] else 1,  # 1: Gold, 0: Gems, 2: ill try
                "Price": 0 if i in [0, 1] else brawlersPrice[selectedRarity] if i == 2 else powerPoints*2,  # Random Price
                "Timer": int((datetime.now() + timedelta(days=1)).timestamp()),  # Timer for 1 day
                "IsOfferSeen": 0,
                "IsOfferPurchased": 0
            }
            print(default_offers)
            default_offers["info"][str(i)] = offer
        if self.hasSpecialOffer:
            default_offers["info"][str(0)] = self.special_offer
        self.save_offers(player_token, default_offers)

    def reroll_offer(self, player_token, i):
        self.special_offer = json.load(open('special_offer.json'))
        self.hasSpecialOffer = self.special_offer["isEnabled"]
        unlockedBrawlers = []
        unlockableBrawlers = Characters.get_brawlers_id()
        for key, brawlerID in self.player.unlocked_brawlers.items():
                unlockedBrawlers.append(int(key))
                unlockableBrawlers.remove(int(key))
        unlockedBrawlersNotMaxed = []
        for brawler in unlockedBrawlers:
                if self.player.unlocked_brawlers[str(brawler)]["PowerPoints"] < 1410:
                    unlockedBrawlersNotMaxed.append(brawler)
        brawlersPrice = [0, 30, 80, 170, 350, 0]
        selectedRarity = random.randint(1, 4)
        brawlersThing = 5 if len(unlockedBrawlersNotMaxed) >= 5 else len(unlockedBrawlersNotMaxed)
        targetBrawlers = random.sample(unlockedBrawlersNotMaxed, brawlersThing)
        new_offers = self.load_offers(self.player.token)
        powerPoints = random.randint(6, 20)
        offer = {
                "OfferID": 4 if i == 0 else 0 if i == 1 else 2 if i == 2 else 8, 
                "Target": [29, Skins.getNonDefaultSkins()] if i == 0 else [0, 0] if i in [1, 2] else [16, targetBrawlers[i-2]],
                "Value": 1 if i in [0, 1] else selectedRarity if i == 2 else powerPoints*2,  # Random Value
                "Amount": 1 if i in [0, 1, 2] else powerPoints,
                "Currency": 0 if i in [0, 1, 2] else 1,  # 0: Gold, 1: Gems, 2: Tokens
                "Price": 0 if i in [0, 1] else brawlersPrice[selectedRarity] if i == 2 else powerPoints*2,  # Random Price
                "Timer": int((datetime.now() + timedelta(days=1)).timestamp()),  # Timer for 1 day
                "IsOfferSeen": 0,
                "IsOfferPurchased": 0
            }
        new_offers["info"][str(i)] = offer
        if self.hasSpecialOffer:
            new_offers["info"][str(0)] = self.special_offer

        self.save_offers(player_token, new_offers)
    def save_offers(self, player_token, offers):
        query = '''
        INSERT INTO PlayerOffers (PlayerToken, Offers)
        VALUES (?, ?)
        ON CONFLICT(PlayerToken) DO UPDATE SET Offers = excluded.Offers;
        '''
        offers_json = json.dumps(offers)
        self.cursor.execute(query, (player_token, offers_json))
        self.connection.commit()
 
    def getPlayerId(self):
        self.cursor.execute("SELECT COUNT(*) FROM Players")
        self.player.low_id = self.cursor.fetchone()[0] + 1

    def createAccount(self):
        self.cursor.execute("SELECT COUNT(*) FROM Players WHERE token = ?", (self.player.token,))
        count = self.cursor.fetchone()[0]
        if count > 0:
            raise ValueError(f"Account with token {self.player.token} already exists.")
        data = {
            "name": self.player.name,
            "low_id": self.player.low_id,
            "club_id": 0,
            "club_role": 0,
            "is_fb_linked": 0,
            "facebook_id": self.player.FacebookID,
            "player_experience": self.player.player_experience,
            "solo_wins": self.player.solo_wins,
            "duo_wins": self.player.duo_wins,
            "three_vs_three_wins": self.player.ThreeVSThree_wins,
            "gems": self.player.gems,
            "gold": self.player.gold,
            "key_reward": 0,
            "trophy_reward": 0,
            "star_key_reward": 0,
            "tokens_doubler": self.player.tokensdoubler,
            "player_tokens": self.player.player_tokens,
            "tickets": self.player.tickets,
            "available_tokens": 500,
            "brawler_id": 0,
            "skin_id": 0,
            "trophies": self.player.trophies,
            "highest_trophies": self.player.trophies,
            "profile_icon": 0,
            "brawl_boxes": self.player.brawl_boxes,
            "big_boxes": self.player.big_boxes,
            "do_not_disturb": 0,
            "room_id": 0,
            "unlocked_brawlers": self.player.unlocked_brawlers,
            "friends": {},
            "last_connection_time": 0,
            "player_status": 0,
            "tutorialState": 2,
            "trophyRoad": self.player.trophyRoad,
            "matchmakeSlot": None,
            "matchmakeState": 0,
            "region": self.player.region,
            "unlockedEvents": 1
        }

        self.cursor.execute("INSERT INTO Players (token, data) VALUES (?, ?)", (self.player.token, json.dumps(data)))
        #self.createOffer(self.player.token)
        self.connection.commit()

    def getAllPlayers(self):
        self.cursor.execute("SELECT data FROM Players")
        results = self.cursor.fetchall()
        return [json.loads(row[0]) for row in results]
    
    def getSpecifiedPlayers(self, tokens):
     players = ",".join(["?"] * len(tokens))
     query = f"SELECT data FROM Players WHERE token IN ({players})"
     self.cursor.execute(query, tokens)
     results = self.cursor.fetchall()
     return [json.loads(row[0]) for row in results]

    def getTokenByLowId(self, low_id):
     self.cursor.execute("SELECT token, data FROM Players")
     results = self.cursor.fetchall()
     for token, data in results:
        player_data = json.loads(data)
        if player_data.get('low_id') == low_id:
            return token 
     return None 
    def getSpecifiedValue(self, value_name):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            return playerData.get(value_name)

    def replaceValue(self, value_name, new_value):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            playerData[value_name] = new_value
            self.cursor.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(playerData), self.player.token))
            self.connection.commit()
    def replaceOtherValue(self, value_name, new_value, token):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            playerData[value_name] = new_value
            self.cursor.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(playerData), token))
            self.connection.commit()

    def appendElementToArray(self, value_name, element):
        self.cursor.execute("SELECT data FROM Players WHERE token = ?", (self.player.token,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            if value_name in playerData and isinstance(playerData[value_name], list):
                playerData[value_name].append(element)
            else:
                playerData[value_name] = [element]
            self.cursor.execute("UPDATE Players SET data = ? WHERE token = ?", (json.dumps(playerData), self.player.token))
            self.connection.commit()
            
    def getRoomId(self):
        self.cursor.execute("SELECT COUNT(*) FROM Gamerooms")
        self.player.room_id = self.cursor.fetchone()[0] + 1

    def createGameroom(self, roomType, chatData):
        
        data = {
            "room_id": self.player.room_id,
            "info": {
                "room_type": roomType,
                "map_id": self.player.map_id,
                "player_count": 1,
                "advertiseToBand": False,
                "advertiseToFriends": False,
                "alreadyAdvertisedToBand": False,
                "players": {
                 self.player.low_id: {
                    "host": True,
                    "low_id": self.player.low_id,
                    "name": self.player.name,
                    "team": self.player.team,
                    "ready": self.player.isReady,
                    "status": 3,
                    "brawler_id": self.player.brawler_id,
                    "skin_id": self.player.skin_id,
                    "profile_icon": self.player.profile_icon
                 }
                }
            }
        }

        self.cursor.execute("INSERT INTO Gamerooms (room_id, data) VALUES (?, ?)", (self.player.room_id, json.dumps(data)))
        
        chatQuery = "INSERT INTO GameroomChats (room_id, data) VALUES (?, ?)"
        self.executeQuery(chatQuery, [self.player.room_id, json.dumps(chatData)])
        self.connection.commit()
    
    def joinGameroom(self, room_id):
     self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (room_id,))
     result = self.cursor.fetchone()
     if not result:
        return False

     data = json.loads(result[0])

     data["info"]["player_count"] += 1
     data["info"]["players"][self.player.low_id] = { 
        "host": False,
        "low_id": self.player.low_id,
        "name": self.player.name,
        "team": self.player.team,
        "ready": self.player.isReady,
        "status": self.player.player_status,
        "brawler_id": self.player.brawler_id,
        "skin_id": self.player.skin_id,
        "profile_icon": self.player.profile_icon
    }

     self.cursor.execute("UPDATE Gamerooms SET data = ? WHERE room_id = ?", (json.dumps(data), room_id))
     self.connection.commit()
     return True

    def loadGameroom(self):
     self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (self.player.room_id,))
     result = self.cursor.fetchone()
     if result:
        gameroomData = json.loads(result[0])
        return gameroomData.get("info", {})
     else:
        self.replaceValue('room_id', 0)
        return {} 

    def executeQuery(self, query, params=None):
        if params is None:
            params = []
        self.cursor.execute(query, params)
        self.connection.commit()

    def fetchOne(self, query, params=None):
        if params is None:
            params = []
        self.cursor.execute(query, params)
        return self.cursor.fetchone()

    def fetchAll(self, query, params=None):
        if params is None:
            params = []
        self.cursor.execute(query, params)
        return self.cursor.fetchall()
    
    def getPlayerInfo(self, lowId):
     self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (self.player.room_id,))
     result = self.cursor.fetchone()
     if result:
        gameroomData = json.loads(result[0])
        self.playerInfo = gameroomData["info"]["players"][str(lowId)]
        return self.playerInfo
     else:
        
        return None

    def updateGameroomPlayerInfo(self, lowId, roomId, playerInfo):
        query = "SELECT data FROM Gamerooms WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            gameroomData = json.loads(data[0])
            gameroomData["info"]["players"][str(lowId)] = playerInfo
            updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])

    def updateGameroomInfo(self, value, roomId, index):
        query = "SELECT data FROM Gamerooms WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            gameroomData = json.loads(data[0])
            gameroomData["info"][index] = value
            updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])
    def getGameroomInfo(self, index):
        self.cursor.execute("SELECT data FROM Gamerooms WHERE room_id = ?", (self.player.room_id,))
        result = self.cursor.fetchone()
        if result:
          gameroomData = json.loads(result[0])
          self.gameroomInfo = gameroomData[index]
          return self.gameroomInfo
        else:
        
          return None

    def removeGameroomPlayer(self, lowId, roomId, token):
     query = "SELECT data FROM Gamerooms WHERE room_id = ?"
     data = self.fetchOne(query, [roomId])
     #gameroomInfo = self.getGameroomInfo("info")
     if data:
        gameroomData = json.loads(data[0])
        if str(lowId) in gameroomData["info"]["players"]:
            del gameroomData["info"]["players"][str(lowId)] 
            gameroomData["info"]["player_count"] -= 1
            updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])
            if gameroomData["info"]["player_count"] == 0:
               self.removeGameroom(roomId)
            else:
               updateQuery = "UPDATE Gamerooms SET data = ? WHERE room_id = ?"
               self.executeQuery(updateQuery, [json.dumps(gameroomData), roomId])
            
        else:
            print(f"Player with LowID {lowId} not found in RoomID {roomId}.")
        
     else:
        print(f"Room with ID {roomId} not found.")
     self.replaceOtherValue('room_id', 0, token)

    def removeGameroom(self, lowId):
     deleteQuery = "DELETE FROM Gamerooms WHERE room_id = ?"
     self.executeQuery(deleteQuery, [lowId])
     deleteQuery = "DELETE FROM GameroomChats WHERE room_id = ?"
     self.executeQuery(deleteQuery, [lowId])
     
    def loadRoomMessages(self, roomId):
        query = "SELECT data FROM GameroomChats WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            return json.loads(data[0])
        return None
    
    def getNextGameroomKey(self, roomId):
        query = "SELECT data FROM GameroomChats WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        nextKey = 0
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            try:
               return int(nextKey)
            except:
               return 0
        return 0

    def addGameroomMsg(self, roomId, eventType, playerId, playerName, msg, event, targetID = 0, targetName = ""):
        query = "SELECT data FROM GameroomChats WHERE room_id = ?"
        data = self.fetchOne(query, [roomId])
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            messages[nextKey] = {
                "EventType": eventType,
                "Event": event,
                "Tick": int(nextKey)+1,
                "PlayerID": playerId,
                "PlayerName": playerName,
                "Message": msg,
                "promotedTeam": self.player.room_id,
                "TimeStamp": time.time(),
                "targetID": targetID,
                "targetName": targetName
            }
            updateQuery = "UPDATE GameroomChats SET data = ? WHERE room_id = ?"
            self.executeQuery(updateQuery, [json.dumps(chatData), roomId])

    def createClub(self, clubId, clubData, chatData):
        clubQuery = "INSERT INTO Clubs (club_id, data) VALUES (?, ?)"
        chatQuery = "INSERT INTO ClubChats (club_id, data) VALUES (?, ?)"
        self.executeQuery(clubQuery, [clubId, json.dumps(clubData)])
        self.executeQuery(chatQuery, [clubId, json.dumps(chatData)])

    def countClubs(self, minMembers, maxMembers, clubType, maxListLength):
     query = "SELECT club_id, data FROM Clubs"
     allClubs = self.fetchAll(query)
     clubList = []
     clubData = []

     for clubId, clubJson in allClubs:
        clubInfo = json.loads(clubJson)
        totalMembers = len(clubInfo["info"]["memberCount"])  # Access "memberCount" directly
        if minMembers <= totalMembers < maxMembers and clubInfo["info"]["clubType"] <= clubType:
            clubList.append(clubId)
            clubData.append(clubInfo)
            if len(clubList) == maxListLength:
                break

     return [clubList, clubData]
 
    def getClubId(self):
        self.cursor.execute("SELECT COUNT(*) FROM Clubs")
        self.player.club_id = self.cursor.fetchone()[0] + 1


    def loadClub(self, clubId):
        query = "SELECT data FROM Clubs WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            return json.loads(data[0])
        return None
    
    def getMemberData(self, token):
        query = "SELECT data FROM Players WHERE token = ?"
        data = self.fetchOne(query, [token])
        if data:
            return json.loads(data[0])
        return None

    def addMember(self, clubId, playerToken, action):
        query = "SELECT data FROM Clubs WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            clubData = json.loads(data[0])
            if action == 0:
                deleteQuery = "DELETE FROM Clubs WHERE club_id = ?"
                self.executeQuery(deleteQuery, [clubId])
            elif action == 1:
                clubData["info"]["memberCount"].append(playerToken)
                updateQuery = "UPDATE CLubs SET data = ? WHERE club_id = ?"
                self.executeQuery(updateQuery, [json.dumps(clubData), clubId])
            elif action == 2:
                clubData["info"]["memberCount"].remove(playerToken)
                updateQuery = "UPDATE Clubs SET data = ? WHERE club_id = ?"
                self.executeQuery(updateQuery, [json.dumps(clubData), clubId])

    def replaceClubValue(self, clubId, description, badgeId, clubType, trophiesNeeded):
        query = "SELECT data FROM Clubs WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            clubData = json.loads(data[0])
            clubData["info"]["description"] = description
            clubData["info"]["clubBadge"] = badgeId
            clubData["info"]["clubType"] = clubType
            clubData["info"]["requiredTrophies"] = trophiesNeeded
            updateQuery = "UPDATE CLubs SET data = ? WHERE club_id = ?"
            self.executeQuery(updateQuery, [json.dumps(clubData), clubId])
            
    def loadClubMessages(self, clubId):
        query = "SELECT data FROM ClubChats WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            return json.loads(data[0])
        return None
    
    def loadEvents(self, state):
        query = "SELECT data FROM Events WHERE state = ?"
        data = self.fetchOne(query, [state])
        if data:
            return json.loads(data[0])
        return None
    
    def loadPlayerOffers(self, token):
        query = "SELECT data FROM PlayerOffers WHERE PlayerToken = ?"
        data = self.fetchOne(query, [token])
        if data:
            return json.loads(data[0])
        return None
    
    def createOffers(self, token):
        self.cursor.execute("SELECT COUNT(*) FROM PlayerOffers WHERE PlayerToken = ?", (token,))
        count = self.cursor.fetchone()[0]
        data = {
            
        }

        self.cursor.execute("INSERT INTO Players (token, data) VALUES (?, ?)", (self.player.token, json.dumps(data)))
        self.createOffer(self.player.token)
        self.connection.commit()
    
    def rerollEvents(self):
        
        self.cursor.execute("SELECT state, data FROM Events WHERE state = ?", [1])
        results = self.cursor.fetchall()
        for state, row in results:
            event = json.loads(row)
            updatedData = json.dumps(event)
        updateQuery = "UPDATE Events SET data = ? WHERE state = ?"
        self.cursor.execute(updateQuery, [updatedData, 2])
        for state, row in results:
            event = json.loads(row)
            
            eventData = event["info"]["events"]

            now = datetime.now()
            tomorrow = now + timedelta(days=1)
            timestamp = int(tomorrow.replace(hour=10, minute=0, second=0, microsecond=0).timestamp())
            for key, data in eventData.items():
                data["TimeStamp"] = timestamp
                if int(key) == 0:
                    gamemodes = Locations.getAllLocationsWithGamemode("CoinRush")
                elif int(key) == 1:
                    gamemodes = Locations.getAllLocationsWithGamemode("BattleRoyale")
                elif int(key) == 2:
                    gamemodes = Locations.getAllLocationsWithException(["CoinRush", "BattleRoyale", "Survival", "BossFight", "BattleRoyaleTeam"])
                elif int(key) == 3:
                    gamemodes = Locations.getAllLocationsWithException(["Survival", "BossFight"])
                else:
                    gamemodes = Locations.getAllLocationsWithGamemode("BattleRoyaleTeam")
                data["ID"] = random.choice(gamemodes)
                data["Modifier"] = {str(random.randint(0, 4)): 1} if int(key) not in [3, 5] else {str(random.randint(1, 3)): random.randint(10, 50)}

        # Convert the modified event back to JSON and update in DB
            updatedData = json.dumps(event)
            updateQuery = "UPDATE Events SET data = ? WHERE state = ?"
            self.cursor.execute(updateQuery, [updatedData, state])

        self.connection.commit()
    
    def getNextKey(self, clubId):
        query = "SELECT data FROM ClubChats WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        nextKey = 0
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            try:
               return int(nextKey)
            except:
               return 0
        return 0

    def addMsg(self, clubId, eventType, playerId, playerName, role, msg, event, targetID = 0, targetName = ""):
        query = "SELECT data FROM ClubChats WHERE club_id = ?"
        data = self.fetchOne(query, [clubId])
        if data:
            chatData = json.loads(data[0])
            messages = chatData["info"]["messages"]
            nextKey = str(max(map(int, messages.keys())) + 1 if messages else 0)
            messages[nextKey] = {
                "EventType": eventType,
                "Event": event,
                "Tick": int(nextKey)+1,
                "PlayerID": playerId,
                "PlayerName": playerName,
                "PlayerRole": role,
                "Message": msg,
                "promotedTeam": self.player.room_id,
                "TimeStamp": time.time(),
                "targetID": targetID,
                "targetName": targetName
            }
            updateQuery = "UPDATE ClubChats SET data = ? WHERE club_id = ?"
            self.executeQuery(updateQuery, [json.dumps(chatData), clubId])
            
    def replaceMessageValue(self, tick, value_name, new_value):
        self.cursor.execute("SELECT data FROM ClubChats WHERE club_id = ?", (self.player.club_id,))
        result = self.cursor.fetchone()
        if result:
            playerData = json.loads(result[0])
            playerData["info"]["messages"][str(tick-1)][value_name] = new_value
            self.cursor.execute("UPDATE ClubChats SET data = ? WHERE club_id = ?", (json.dumps(playerData), self.player.club_id))
            self.connection.commit()
            
    
            
    def createMMPool(self, index, selectedBrawler):
      data = {
        "slot": index,
        "info": {
            "PlayerCount": 1,
            "map": 0,
            "players": {self.player.token: selectedBrawler}
        }
      }
      self.cursor.execute("INSERT INTO Matchmake (slot, data) VALUES (?, ?)", (index, json.dumps(data)))
      self.conn.commit()
    def joinMMPool(self, index, brawlerID):
      self.cursor.execute("SELECT data FROM Matchmake WHERE slot = ?", (index,))
      result = self.cursor.fetchone()
      if result:
        data = json.loads(result[0])

        data["info"]["PlayerCount"] += 1
        data["info"]["players"][self.player.token] = brawlerID

        self.cursor.execute("UPDATE Matchmake SET data = ? WHERE slot = ?", (json.dumps(data), index))
        self.conn.commit()
    def leaveMMPool(self, index):
     self.cursor.execute("SELECT data FROM Matchmake WHERE slot = ?", (index,))
     result = self.cursor.fetchone()
     if result:
        data = json.loads(result[0])

        if data["info"]["PlayerCount"] == 1:
            self.cursor.execute("DELETE FROM Matchmake WHERE slot = ?", (index,))
        else:
            if self.player.token in data["info"]["players"]:
                del data["info"]["players"][self.player.token]
                data["info"]["PlayerCount"] -= 1

                self.cursor.execute("UPDATE Matchmake SET data = ? WHERE slot = ?", (json.dumps(data), index))
        self.conn.commit()

    def loadMMPool(self, index):
      self.cursor.execute("SELECT data FROM Matchmake WHERE slot = ?", (index,))
      result = self.cursor.fetchone()
      if result:
        data = json.loads(result[0])
        self.slot = data["slot"]
        self.playercount = data["info"]["PlayerCount"]
        self.map = data["info"]["map"]
        self.matchmakedata = data["info"]["players"]
      else:
        raise IndexError(f"Matchmaking pool not found for slot {index}")
    def removeMMPool(self, index):
     self.cursor.execute("DELETE FROM MatchmakingPool WHERE slot = ?", (index,))
     self.conn.commit()


    def __del__(self):
        self.connection.close()
